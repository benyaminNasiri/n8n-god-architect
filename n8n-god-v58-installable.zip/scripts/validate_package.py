#!/usr/bin/env python3
"""Validate the n8n-god skill package itself."""

from __future__ import annotations

import ast
import json
import pathlib
import re
import sys

root = pathlib.Path(__file__).resolve().parents[1]
errors: list[str] = []

skill_path = root / "SKILL.md"
if not skill_path.is_file():
    errors.append("SKILL.md missing")
else:
    text = skill_path.read_text(encoding="utf-8")
    match = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not match:
        errors.append("SKILL.md frontmatter missing or malformed")
    else:
        keys = [line.split(":", 1)[0].strip() for line in match.group(1).splitlines() if ":" in line]
        if keys != ["name", "description"]:
            errors.append(f"frontmatter must contain only name and description, found: {keys}")
        if "name: n8n-god" not in match.group(0):
            errors.append("frontmatter name must be n8n-god")
    for ref in re.findall(r"`((?:references|scripts|assets)/[^`]+)`", text):
        if any(char in ref for char in "*<>"):
            continue
        if not (root / ref).exists():
            errors.append(f"referenced resource missing: {ref}")

for forbidden in ("README.md", "INSTALLATION_GUIDE.md", "QUICK_REFERENCE.md", "CHANGELOG.md"):
    if (root / forbidden).exists():
        errors.append(f"extraneous top-level file: {forbidden}")

for path in root.rglob("*.json"):
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"invalid json: {path.relative_to(root)}: {exc}")

for path in root.rglob("*.jsonl"):
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            json.loads(line)
        except Exception as exc:
            errors.append(f"invalid jsonl: {path.relative_to(root)}:{number}: {exc}")

for path in root.rglob("*.py"):
    try:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as exc:
        errors.append(f"invalid python: {path.relative_to(root)}: {exc}")

secret_patterns = [
    re.compile(rb"AIza[0-9A-Za-z_-]{30,}"),
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(rb"gh[pousr]_[A-Za-z0-9]{20,}"),
]
for path in root.rglob("*"):
    if not path.is_file() or path.name == "MANIFEST.sha256":
        continue
    data = path.read_bytes()
    for pattern in secret_patterns:
        if pattern.search(data):
            errors.append(f"possible secret: {path.relative_to(root)}")

if errors:
    print("\n".join(errors))
    raise SystemExit(1)
print("package validation passed")
