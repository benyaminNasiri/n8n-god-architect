#!/usr/bin/env python3
"""Score n8n production readiness from an explicit evidence ledger."""

from __future__ import annotations

import argparse
import json
import pathlib
import sys

WEIGHTS = {
    "business_fit": 10,
    "architecture": 15,
    "functional_correctness": 15,
    "reliability_recovery": 15,
    "security_privacy": 15,
    "observability_operations": 10,
    "performance_scalability": 7,
    "cost_efficiency": 5,
    "maintainability": 5,
    "documentation_ownership": 3,
}
LEVELS = {f"E{i}": i for i in range(7)}


def main() -> int:
    parser = argparse.ArgumentParser(description="Score n8n readiness evidence")
    parser.add_argument("evidence", type=pathlib.Path)
    parser.add_argument("--json-output", type=pathlib.Path)
    args = parser.parse_args()

    try:
        data = json.loads(args.evidence.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"evidence JSON نامعتبر: {exc}", file=sys.stderr)
        return 2

    errors: list[str] = []
    scores = data.get("scores", {})
    normalized: dict[str, int] = {}
    for domain, maximum in WEIGHTS.items():
        value = scores.get(domain)
        if not isinstance(value, int) or value < 0 or value > maximum:
            errors.append(f"{domain} باید عدد صحیح بین ۰ و {maximum} باشد")
        else:
            normalized[domain] = value

    level = data.get("evidence_level")
    if level not in LEVELS:
        errors.append("evidence_level باید E0 تا E6 باشد")
    blockers = data.get("hard_blockers", [])
    if not isinstance(blockers, list) or any(not isinstance(item, str) for item in blockers):
        errors.append("hard_blockers باید آرایه رشته باشد")
        blockers = ["invalid hard_blockers"]

    if errors:
        print(json.dumps({"status": "invalid", "errors": errors}, ensure_ascii=False, indent=2))
        return 2

    total = sum(normalized.values())
    security_pct = normalized["security_privacy"] / WEIGHTS["security_privacy"] * 100
    reliability_pct = normalized["reliability_recovery"] / WEIGHTS["reliability_recovery"] * 100

    if LEVELS[level] >= 6 and total >= 85 and security_pct >= 80 and reliability_pct >= 80 and not blockers:
        verdict = "production-proven"
    elif LEVELS[level] >= 5 and total >= 85 and security_pct >= 80 and reliability_pct >= 80 and not blockers:
        verdict = "production-ready"
    elif total >= 70:
        verdict = "production-release-candidate" if total >= 85 else "staging-only"
    elif total >= 50:
        verdict = "prototype"
    else:
        verdict = "redesign"

    result = {
        "status": "scored",
        "score": total,
        "maximum": 100,
        "evidence_level": level,
        "security_percent": round(security_pct, 1),
        "reliability_percent": round(reliability_pct, 1),
        "hard_blockers": blockers,
        "verdict": verdict,
    }
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.json_output:
        args.json_output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
