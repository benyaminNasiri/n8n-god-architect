#!/usr/bin/env python3
"""Create a deterministic, secret-scanned n8n release ZIP."""

from __future__ import annotations

import argparse
import hashlib
import pathlib
import re
import sys
import zipfile

SECRET_PATTERNS = [
    re.compile(rb"AIza[0-9A-Za-z_-]{30,}"),
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(rb"gh[pousr]_[A-Za-z0-9]{20,}"),
]
EXCLUDED_PARTS = {".git", "__pycache__", "node_modules", ".venv"}


def allowed(path: pathlib.Path) -> bool:
    if any(part in EXCLUDED_PARTS for part in path.parts):
        return False
    name = path.name.lower()
    if name.endswith((".zip", ".pyc", ".pem", ".key", ".p12", ".pfx")):
        return False
    if name.startswith(".env") and not name.endswith((".example", ".sample", ".template")):
        return False
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Build deterministic n8n release bundle")
    parser.add_argument("project", type=pathlib.Path)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    args = parser.parse_args()

    root = args.project.resolve()
    output = args.output.resolve()
    if not root.is_dir():
        print(f"Project directory not found: {root}", file=sys.stderr)
        return 2
    if output.is_relative_to(root):
        print("Output ZIP must be outside the project directory", file=sys.stderr)
        return 2

    files = sorted(path for path in root.rglob("*") if path.is_file() and allowed(path.relative_to(root)))
    if not files:
        print("No files to package", file=sys.stderr)
        return 2

    hashes: list[str] = []
    for path in files:
        data = path.read_bytes()
        for pattern in SECRET_PATTERNS:
            if pattern.search(data):
                print(f"Possible secret in {path.relative_to(root)}", file=sys.stderr)
                return 1
        digest = hashlib.sha256(data).hexdigest()
        hashes.append(f"{digest}  {path.relative_to(root).as_posix()}")

    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o755 if path.stat().st_mode & 0o111 else 0o644) << 16
            archive.writestr(info, path.read_bytes())
        manifest = "\n".join(hashes) + "\n"
        info = zipfile.ZipInfo("MANIFEST.sha256", date_time=(2026, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        archive.writestr(info, manifest.encode("utf-8"))

    print(f"bundle={output}")
    print(f"sha256={hashlib.sha256(output.read_bytes()).hexdigest()}")
    print(f"files={len(files) + 1}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
