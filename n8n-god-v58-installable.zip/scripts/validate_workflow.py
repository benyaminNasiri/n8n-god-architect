#!/usr/bin/env python3
"""Deterministic static validator for n8n workflow projects."""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys
from typing import Any

SECRET_PATTERNS = {
    "google_api_key": re.compile(r"AIza[0-9A-Za-z_-]{30,}"),
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "github_token": re.compile(r"gh[pousr]_[A-Za-z0-9]{20,}"),
    "generic_secret": re.compile(
        r"(?i)(?:api[_-]?key|authorization|password|secret|token)\s*[=:]\s*[\"'][^\"']{8,}[\"']"
    ),
}


def load_json(path: pathlib.Path, errors: list[str]) -> Any | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"{path.name}: JSON نامعتبر: {exc}")
        return None


def is_workflow(value: Any) -> bool:
    return isinstance(value, dict) and isinstance(value.get("nodes"), list) and isinstance(value.get("connections"), dict)


def walk_edges(value: Any):
    if isinstance(value, dict):
        if isinstance(value.get("node"), str):
            yield value["node"]
        for child in value.values():
            yield from walk_edges(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_edges(child)


def validate_workflow(path: pathlib.Path, workflow: dict[str, Any], errors: list[str], warnings: list[str], webhook_paths: dict[str, str]) -> None:
    label = path.name
    nodes = workflow.get("nodes", [])
    names = [node.get("name") for node in nodes]
    ids = [node.get("id") for node in nodes]

    if not workflow.get("name"):
        errors.append(f"{label}: نام Workflow وجود ندارد")
    if not nodes:
        errors.append(f"{label}: هیچ Node ندارد")
    if any(not isinstance(name, str) or not name.strip() for name in names):
        errors.append(f"{label}: Node بدون نام معتبر")
    if len(names) != len(set(names)):
        errors.append(f"{label}: نام Node تکراری")
    if any(not isinstance(node_id, str) or not node_id.strip() for node_id in ids):
        errors.append(f"{label}: Node بدون id معتبر")
    if len(ids) != len(set(ids)):
        errors.append(f"{label}: id تکراری Node")

    known = set(names)
    for source, mapping in workflow.get("connections", {}).items():
        if source not in known:
            errors.append(f"{label}: مبدأ Connection وجود ندارد: {source}")
        for target in walk_edges(mapping):
            if target not in known:
                errors.append(f"{label}: مقصد Connection وجود ندارد: {target}")

    has_error_trigger = False
    for node in nodes:
        name = node.get("name", "<unnamed>")
        node_type = str(node.get("type", ""))
        if "typeVersion" not in node:
            errors.append(f"{label}: {name}: typeVersion وجود ندارد")
        if node.get("disabled") is True:
            warnings.append(f"{label}: {name}: Node غیرفعال است")
        if node.get("continueOnFail") is True:
            warnings.append(f"{label}: {name}: Continue On Fail قدیمی نیازمند بررسی معنای downstream است")
        if node.get("onError") == "continueRegularOutput":
            warnings.append(f"{label}: {name}: خطا وارد خروجی عادی می‌شود؛ downstream باید آن را صریح تشخیص دهد")
        if node.get("retryOnFail") is True:
            tries = node.get("maxTries")
            if not isinstance(tries, int) or tries < 1 or tries > 10:
                errors.append(f"{label}: {name}: maxTries باید عدد محدود ۱ تا ۱۰ باشد")
        if node_type.endswith(".errorTrigger"):
            has_error_trigger = True
        if node_type.endswith(".webhook"):
            parameters = node.get("parameters", {})
            webhook_path = parameters.get("path")
            if not webhook_path:
                errors.append(f"{label}: {name}: مسیر Webhook وجود ندارد")
            elif webhook_path in webhook_paths:
                errors.append(f"{label}: مسیر Webhook تکراری با {webhook_paths[webhook_path]}: {webhook_path}")
            else:
                webhook_paths[str(webhook_path)] = label
            if parameters.get("authentication") in (None, "none"):
                warnings.append(f"{label}: {name}: Webhook بدون احراز هویت Node-level؛ کنترل Edge باید اثبات شود")
        credentials = node.get("credentials")
        if credentials:
            for kind, ref in credentials.items():
                if not isinstance(ref, dict) or not ref.get("name") or not ref.get("id"):
                    errors.append(f"{label}: {name}: Credential reference ناقص برای {kind}")
        if "agent" in node_type.lower():
            params = node.get("parameters", {})
            bounded = any(key in params for key in ("maxIterations", "maxSteps", "maxExecutions"))
            if not bounded:
                warnings.append(f"{label}: {name}: محدودیت Agent loop در JSON قابل اثبات نیست")

    settings = workflow.get("settings", {})
    if not settings.get("timezone"):
        errors.append(f"{label}: timezone صریح وجود ندارد")
    if not settings.get("executionOrder"):
        errors.append(f"{label}: executionOrder صریح وجود ندارد")
    if not has_error_trigger and not settings.get("errorWorkflow"):
        warnings.append(f"{label}: Error Workflow مرجع ندارد")
    if workflow.get("active") is True:
        warnings.append(f"{label}: Artifact در حالت active صادر شده است")


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate n8n workflow JSON and package controls")
    parser.add_argument("project", type=pathlib.Path)
    parser.add_argument("--report", type=pathlib.Path)
    parser.add_argument("--strict", action="store_true", help="Treat warnings as failures")
    args = parser.parse_args()

    root = args.project.resolve()
    errors: list[str] = []
    warnings: list[str] = []
    workflows = 0
    webhook_paths: dict[str, str] = {}

    if not root.is_dir():
        print(f"Project directory not found: {root}", file=sys.stderr)
        return 2

    for path in sorted(root.rglob("*.json")):
        value = load_json(path, errors)
        if is_workflow(value):
            workflows += 1
            validate_workflow(path, value, errors, warnings, webhook_paths)

    if workflows == 0:
        errors.append("هیچ Workflow JSON شناسایی نشد")

    if any(path.name.lower().startswith("fixture") for path in root.rglob("*.json")):
        warnings.append("Fixture شناسایی شد؛ Static Validator آن را اجرا نمی‌کند و این مورد E3 محسوب نمی‌شود")

    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError as exc:
            errors.append(f"{path.relative_to(root)}: خطای خواندن: {exc}")
            continue
        for name, pattern in SECRET_PATTERNS.items():
            if pattern.search(text):
                errors.append(f"{path.relative_to(root)}: Secret احتمالی ({name})")

    report = {
        "project": str(root),
        "workflow_count": workflows,
        "errors": errors,
        "warnings": warnings,
        "status": "fail" if errors or (args.strict and warnings) else "pass",
        "evidence_level": "E2" if not errors else "E0",
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.report:
        args.report.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 1 if report["status"] == "fail" else 0


if __name__ == "__main__":
    raise SystemExit(main())
