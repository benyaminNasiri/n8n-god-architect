# n8n Architect Intelligence Engine v55 — Consolidated Source


---

# FILE: 00_CORE/01_architect_identity.md

# Architect Identity

معمار n8n سه سطح را هم‌زمان می‌بیند:

## Business Plane
- چه فرایندی باید بهتر شود؟
- success metric چیست؟
- چه داده‌ای authoritative است؟
- چه اقداماتی reversible نیست؟

## Automation Plane
- trigger چیست؟
- orchestration کجا قرار می‌گیرد؟
- state کجا ذخیره می‌شود؟
- چه side effectهایی وجود دارد؟

## Platform Plane
- execution چگونه scale می‌شود؟
- security boundary چیست؟
- observability چگونه انجام می‌شود؟
- deployment چگونه قابل rollback است؟

## Definition of Done

Workflow تنها زمانی تمام‌شده محسوب می‌شود که:
- success path کار کند.
- failure path تعریف شده باشد.
- business state قابل اثبات باشد.
- duplicate execution امن باشد.
- owner و runbook مشخص باشد.


---

# FILE: 00_CORE/02_principles.md

# Core Engineering Principles

## Determinism First
هر جا تصمیم AI لازم نیست، deterministic logic ترجیح دارد.

## Explicit State
State مهم باید در DB یا durable store باشد، نه فقط در memory یا execution payload.

## Small Contracts
Sub-workflowها باید input/output روشن داشته باشند.

## Idempotency Before Retry
Retry بدون idempotency می‌تواند duplicate payment، duplicate message یا duplicate record ایجاد کند.

## Least Privilege
Permission کاربر، API key، credential، Agent tool و DB role باید حداقل لازم باشد.

## Fail Loudly, Recover Deliberately
خطا نباید silently swallow شود. Failure باید classify، persist و قابل recovery باشد.

## Version Everything
Workflow، prompts، schema، agent tools و DB migrations همگی باید نسخه داشته باشند.

## Observe Business Outcomes
صرف success execution کافی نیست. مثلا «پیام ارسال شد» با «follow-up انجام شد» متفاوت است.


---

# FILE: 00_CORE/03_decision_framework.md

# Architecture Decision Framework

## Step 1 — Classify Workload

### Synchronous API
زمان کوتاه، پاسخ مستقیم لازم.
Pattern: validate → execute → respond.

### Async Job
زمان طولانی یا غیرقابل پیش‌بینی.
Pattern: accept → create job → 202/job_id → worker.

### Batch/ETL
رکورد زیاد و cursor/pagination.
Pattern: batch → checkpoint → persist → next.

### Human Process
Approval یا wait طولانی.
Pattern: action → wait/resume → decision.

### Agentic
نیاز به reasoning/tool selection.
Pattern: router/agent → restricted tool → validate → action.

## Step 2 — Risk Tier

- Low: read-only / internal.
- Medium: writes reversible.
- High: customer communication، money، sensitive data.
- Critical: destructive/admin/security/financial.

Risk tier determines approval, audit, testing and rollback rigor.

## Step 3 — Scale Tier

- S1: <100 executions/day
- S2: hundreds/thousands/day
- S3: tens of thousands/day
- S4: high-concurrency distributed platform

Do not over-engineer S1, but do not design S4 like S1.


---

# FILE: 00_CORE/04_architecture_scoring.md

# Architecture Scoring Model

Score 100:

- Correctness: 20
- Reliability: 15
- Security: 15
- Maintainability: 15
- Scalability: 10
- Observability: 10
- Testability: 5
- Cost efficiency: 5
- Operability: 5

## Gate Rules

- Security < 10/15 → production block.
- Reliability < 10/15 → production block for critical workflow.
- No owner/runbook → production block.
- No rollback for schema-changing deployment → production block.


---

# FILE: 01_RUNTIME/01_execution_model.md

# n8n Execution Model

## Core mental model

Workflow = directed graph of nodes + execution context + item data + credentials + runtime mode.

هر Node می‌تواند:
- داده بخواند/تبدیل کند.
- API call انجام دهد.
- side effect ایجاد کند.
- branch ایجاد کند.
- workflow دیگر را invoke کند.

## Execution Modes

Design باید بین manual/test و production تفاوت قائل شود. Pinned/test data نباید به‌عنوان رفتار Production فرض شود.

## Item Lineage

وقتی داده از چند item می‌آید، lineage اهمیت دارد. custom/programmatic transform باید mapping ورودی به خروجی را حفظ کند تا expressionهای ارجاعی ambiguous نشوند.

## Partial Execution Risk

Node-level یا partial run برای debugging مفید است اما ممکن است state، side effect و upstream conditions واقعی Production را بازسازی نکند.

## Rule

هر workflow حیاتی باید حداقل یک full-path production-like test داشته باشد.


---

# FILE: 01_RUNTIME/02_queue_mode.md

# Queue Mode Architecture

## Components

### Main
- UI/API/control plane
- workflow management
- orchestration responsibilities

### Redis
- job queue
- coordination
- transient queue state

### Workers
- actual workflow execution
- horizontally scalable compute

### Webhook Processors
برای جداسازی inbound webhook traffic از Main در scale بالا.

### PostgreSQL
durable metadata/execution persistence.

## Reference Topology

```text
Load Balancer
 ├─ Main/UI
 └─ Webhook Processors
         ↓
       Redis
    ┌────┼────┐
 Worker Worker Worker
    └────┼────┘
     PostgreSQL
```

## Capacity Concerns

Scale فقط با تعداد Worker تعیین نمی‌شود:
- DB connections
- Redis latency
- worker concurrency
- CPU/RAM
- external API rate limits
- task duration
- binary payload sizes

## Anti-pattern
100 worker با concurrency بسیار پایین می‌تواند DB connection overhead ایجاد کند بدون اینکه throughput واقعی بهتر شود.


---

# FILE: 01_RUNTIME/03_task_runners.md

# Task Runner Architecture

Code execution باید به‌عنوان یک security boundary دیده شود.

## Why isolate
Code Node می‌تواند از نظر capability قوی‌تر از یک integration node باشد. در محیط multi-user یا untrusted workflow، اجرای code در process اصلی ریسک بالایی دارد.

## Recommended model

```text
Worker
  ↓
Task Broker
  ↓
External Task Runner
```

## Hardening

- container جدا
- filesystem حداقلی/read-only در صورت امکان
- non-root
- network محدود
- environment secrets حداقل
- resource limits
- per-worker runner topology در scale distributed

## Operational Checks

- runner connectivity
- memory limit
- task timeout
- crash behavior
- version compatibility


---

# FILE: 01_RUNTIME/04_webhooks_and_async.md

# Webhooks and Async Processing

## Synchronous webhook

مناسب:
- validation ساده
- lookup سریع
- command کوتاه

نامناسب:
- scraping طولانی
- heavy AI pipeline
- large file processing

## Async pattern

```text
POST /job
  ↓
Validate
  ↓
Create job record
  ↓
Return 202 + job_id
  ↓
Background execution
  ↓
Persist result
  ↓
Callback/poll/notification
```

## Response Rules

- response contract مشخص.
- timeout upstream/client را در نظر بگیر.
- duplicate webhook handling با idempotency/event id.
- signature/auth validation قبل از side effect.


---

# FILE: 01_RUNTIME/05_binary_files.md

# Binary Data and Files

## Principle
DB برای metadata، object storage برای binary بزرگ.

Examples:
- voice
- image
- PDF
- video
- spreadsheet

## Pipeline

```text
Receive file
 ↓
Validate type/size
 ↓
Store binary
 ↓
Persist metadata + object key
 ↓
Process asynchronously
```

## Controls

- file size limit
- MIME validation
- malware/security scanning where required
- lifecycle/retention
- signed URLs
- avoid embedding huge binary payloads through many nodes


---

# FILE: 01_RUNTIME/06_timeouts_graceful_shutdown.md

# Timeouts and Graceful Shutdown

## Timeout layers

- workflow timeout
- HTTP request timeout
- DB timeout
- AI model timeout
- queue/job timeout

هر لایه باید مستقل و آگاهانه تنظیم شود.

## Graceful shutdown

Process termination باید:
1. readiness را false کند.
2. job جدید نگیرد.
3. executionهای active را drain کند.
4. سپس terminate شود.

## Failure mode
Kill ناگهانی worker در وسط side effect ممکن است state نامشخص ایجاد کند. برای عملیات مهم، business-level reconciliation لازم است.


---

# FILE: 02_WORKFLOW_ENGINEERING/01_contracts.md

# Workflow Contracts

هر Workflow جدی باید Contract داشته باشد.

## Input Contract
- fields
- types
- required/optional
- enum/range
- provenance
- PII classification

## Output Contract
- success schema
- business status
- error schema
- correlation_id
- version

## Side Effects
صریح بنویس:
- چه DBای تغییر می‌کند؟
- چه پیام/ایمیلی ارسال می‌شود؟
- چه external APIای تغییر می‌کند؟

## Operational Contract
- timeout
- retry
- idempotency
- concurrency
- owner
- SLO


---

# FILE: 02_WORKFLOW_ENGINEERING/02_modularity.md

# Modularity and Sub-workflows

## Good decomposition

یک Sub-workflow باید یک domain operation انجام دهد:
- `crm.create_doctor`
- `crm.create_followup`
- `scrape.fetch_page`
- `content.publish_post`

## Bad decomposition
- helper1
- misc
- do_everything
- 80-node monolith

## Rules
- input/output روشن
- parent internals را نداند
- credentials داخل domain boundary
- side effects document شوند
- reusable operation stable باشد


---

# FILE: 02_WORKFLOW_ENGINEERING/03_patterns.md

# Workflow Pattern Library

## Pipeline
Validate → Transform → Enrich → Persist → Notify.

## Controller/Worker
Controller job را orchestration می‌کند؛ Worker operation کوچک انجام می‌دهد.

## Fan-out/Fan-in
Jobها تقسیم، parallelized و سپس aggregate می‌شوند. نیازمند correlation key.

## Outbox
DB transaction + outbox event، سپس external action.

## DLQ
Failure بعد از retry به queue/table جدا منتقل می‌شود.

## Saga
هر step مهم compensation دارد.

## Human Approval
Wait/resume، نه polling طولانی.

## Reconciliation
دوره‌ای expected state را با actual state مقایسه می‌کند.


---

# FILE: 02_WORKFLOW_ENGINEERING/04_anti_patterns.md

# Workflow Anti-patterns

## Giant Canvas
نشانه: تغییر کوچک چند بخش را می‌شکند.
راه‌حل: domain sub-workflows.

## Hidden Logic in Expressions
نشانه: business rule فقط داخل expressionهای طولانی.
راه‌حل: explicit transform/validation.

## Retry Everything
مشکل: permanent failure و duplicate side effects.
راه‌حل: classify errors.

## Swallow Error
مشکل: execution سبز ولی business process ناقص.
راه‌حل: business validation + explicit failure.

## State in Execution Only
مشکل: pruning/history loss = state loss.
راه‌حل: durable business DB.

## Agent as Universal Router
مشکل: هزینه/عدم قطعیت غیرضروری.
راه‌حل: deterministic routing first.


---

# FILE: 02_WORKFLOW_ENGINEERING/05_naming_structure.md

# Naming and Structure

## Workflow naming
`DOMAIN.ACTION.OBJECT.vN`

Examples:
- `CRM.CREATE.DOCTOR.v2`
- `SCRAPE.FETCH.PAGE.v1`
- `CONTENT.PUBLISH.POST.v3`

## Node naming
نام باید intent را بگوید:
- `Validate Input`
- `Lookup Existing Doctor`
- `Upsert Followup`

نه:
- `Set1`
- `HTTP Request2`

## Tags
- env:prod/stage/dev
- domain:crm/scrape/content
- criticality:low/high
- owner:team-name


---

# FILE: 02_WORKFLOW_ENGINEERING/06_idempotency_design.md

# Idempotency Design

## Core question
اگر همین event دوبار رسید چه می‌شود؟

## Keys
- webhook event id
- business natural key
- generated idempotency key

## Strategies
- unique DB constraint
- upsert
- processed_event table
- external API idempotency key

## Example
`doctor_phone + visit_date + report_type` می‌تواند برای جلوگیری از duplicate report استفاده شود، اگر domain rules آن را تایید کند.

## Never
Retry write operation بدون تعریف duplicate behavior.


---

# FILE: 03_NODE_INTELLIGENCE/01_selection_matrix.md

# Node Selection Matrix

اولویت عمومی:

1. Built-in node
2. HTTP/API node with explicit contract
3. Verified/audited community node
4. Custom node
5. Code node for logic that genuinely needs code

## Selection dimensions
- official maintenance
- auth support
- pagination
- rate-limit behavior
- error surface
- binary support
- item semantics
- security
- version stability

## Rule
کوتاه‌ترین workflow لزوماً بهترین workflow نیست؛ clarity و failure control مهم‌تر است.


---

# FILE: 03_NODE_INTELLIGENCE/02_core_nodes.md

# Core Node Intelligence

## Webhook
Use: inbound API/event.
Watch: auth, signatures, response mode, duplicate delivery.

## HTTP Request
Use: generic APIs.
Watch: timeout, pagination, retries, SSRF, auth, response validation.

## IF / Switch
Use: deterministic routing.
Watch: implicit defaults and missing branches.

## Merge
Use: synchronization/aggregation.
Watch: item pairing and cardinality.

## Code
Use: complex transform, not universal escape hatch.
Watch: security, performance, item lineage, runtime compatibility.

## Wait
Use: human approval, delayed resume, event resume.
Watch: timeout/expiry and resume authorization.


---

# FILE: 03_NODE_INTELLIGENCE/03_database_nodes.md

# Database Node Intelligence

## Reads
- parameterize queries
- select only required columns
- index lookup fields
- paginate large result sets

## Writes
- transaction semantics where needed
- unique constraints
- upsert for idempotent ingestion
- capture affected row/entity id

## Anti-patterns
- SQL string concatenation from user input
- `SELECT *` on large tables
- bulk writes one row per execution when batch is available
- using admin/service-role credential for read-only task


---

# FILE: 03_NODE_INTELLIGENCE/04_ai_nodes.md

# AI Node Intelligence

## Model node
Define:
- model
- temperature/reasoning settings
- timeout
- cost budget
- structured output requirement

## Agent node
Use only when dynamic tool choice is required.

## Memory
Production distributed systems need durable/shared memory if session continuity matters.

## Retriever/Vector Store
Separate retrieval quality from generation quality.

## Structured Output
Always validate machine-actionable AI output against schema before side effect.


---

# FILE: 03_NODE_INTELLIGENCE/05_custom_nodes.md

# Custom Node Engineering

## Declarative
Best for standard REST resources/actions.

## Programmatic
Best for:
- complex control flow
- binary
- custom pagination
- custom triggers
- advanced errors

## Requirements
- versioning
- credential abstraction
- tests
- item linkage
- changelog
- backwards compatibility plan
- lint/build pipeline

## Security
Custom node is code running with platform privileges. Treat dependency chain as supply-chain risk.


---

# FILE: 04_INTEGRATIONS/01_api_engineering.md

# API Engineering

## Request contract
- method/path
- auth
- timeout
- retry
- expected status
- response schema

## Pagination
Persist cursor/checkpoint for large jobs.

## Rate limits
Respect:
- 429
- Retry-After
- provider quotas
- concurrency limits

## Error classification
- 400 validation → no blind retry
- 401 auth → refresh/fix credential
- 403 permission → stop/escalate
- 429 rate limit → backoff
- 5xx transient → bounded retry


---

# FILE: 04_INTEGRATIONS/02_webhook_security.md

# Webhook Security

Controls:
- TLS
- authentication/signature
- timestamp/replay window
- body size limit
- schema validation
- idempotency
- rate limiting
- correlation id

## Signature workflow
1. capture raw payload if signature depends on raw bytes.
2. verify signature.
3. verify timestamp.
4. reject replay.
5. only then parse/process side effect.


---

# FILE: 04_INTEGRATIONS/03_pagination_checkpoint.md

# Pagination and Checkpointing

Large ingestion must be resumable.

Persist:
- job_id
- cursor/page
- processed_count
- failed_count
- last_success_at

## Batch algorithm

```text
Load checkpoint
 ↓
Fetch page
 ↓
Validate
 ↓
Upsert batch
 ↓
Commit checkpoint
 ↓
Next page
```

Checkpoint must be committed after durable data commit, not before.


---

# FILE: 04_INTEGRATIONS/04_files_and_storage.md

# File Integration

## Metadata
- object key
- original name
- MIME
- size
- checksum
- owner/entity id
- retention

## Processing
Prefer object reference between workflows rather than copying large binary repeatedly.

## Security
- sanitize filenames
- no path traversal
- signed URL expiry
- private buckets by default
- content type validation


---

# FILE: 05_AI_AGENT_MCP/01_agent_architecture.md

# Production Agent Architecture

```text
Input
 ↓
Auth / Tenant
 ↓
Deterministic pre-routing
 ↓
Guardrails
 ↓
Agent
 ↓
Restricted Tool
 ↓
Schema Validation
 ↓
Policy Check
 ↓
Approval if needed
 ↓
Action
 ↓
Audit
```

## Agent should reason about
- intent
- tool choice
- parameters
- result interpretation

## Agent should not own
- raw admin DB access
- unrestricted code execution
- implicit destructive permissions


---

# FILE: 05_AI_AGENT_MCP/02_tool_design.md

# Tool Design

Bad:
`manage_crm(anything)`

Good:
- `find_doctor_by_phone`
- `create_followup`
- `update_contact_info`
- `list_overdue_tasks`

## Tool contract
- purpose
- input schema
- output schema
- side effects
- permission scope
- idempotency
- errors
- audit fields

## Rule
Tool باید کوچک‌تر از business domain باشد و بزرگ‌تر از یک raw SQL primitive.


---

# FILE: 05_AI_AGENT_MCP/03_memory.md

# Agent Memory Architecture

## Working memory
Context of current turn/task.

## Session memory
Conversation continuity.

## Business memory
Facts in authoritative DB; do not duplicate truth into chat memory.

## Knowledge memory
Documents/policies/patterns.

## Long-term architecture memory
Decisions, incidents, preferred conventions.

## Rule
Memory is not authorization. Agent remembering a fact does not grant permission to act.


---

# FILE: 05_AI_AGENT_MCP/04_rag.md

# RAG Architecture

Pipeline:
Document → parse → chunk → metadata → embedding → vector store → retrieve → rerank → generate → cite/evaluate.

## Quality dimensions
- retrieval recall
- retrieval precision
- grounding
- freshness
- access filtering
- citation correctness

## Security
Apply authorization before retrieval, not after generation.


---

# FILE: 05_AI_AGENT_MCP/05_mcp.md

# MCP Engineering

MCP is a tool/context interface, not a permission bypass.

## Tool governance
- discover tools
- whitelist needed tools
- validate schemas
- scope credentials
- log calls
- restrict side effects

## MCP readiness test
Schema validation alone is insufficient. Operational test should confirm:
- server reachable
- auth valid
- tools discoverable
- representative tool executes safely

## Tool filtering
Agent should see the smallest set of tools for its role.


---

# FILE: 05_AI_AGENT_MCP/06_agent_evaluation.md

# Agent Evaluation

Dataset categories:
- happy path
- ambiguous input
- missing data
- tool error
- permission denial
- adversarial input
- duplicate request
- high-risk action

Metrics:
- task completion
- tool selection
- parameter correctness
- groundedness
- unsafe action rate
- latency
- cost

Every production incident should become a regression test when practical.


---

# FILE: 06_SECURITY/01_threat_model.md

# Threat Model

Attack surfaces:
- public webhooks
- API keys
- credential sharing
- Code/Community nodes
- SSRF
- SQL injection
- prompt injection
- file upload
- MCP tools
- internal admin APIs

For each threat document:
- asset
- attacker capability
- entry point
- impact
- control
- detection
- recovery


---

# FILE: 06_SECURITY/02_credentials_secrets.md

# Credentials and Secrets

## Rules
- no secret in workflow JSON
- no secret in prompt
- separate prod/stage/dev credentials
- rotate high-value secrets
- credential ownership documented
- service accounts preferred over personal accounts
- minimum API scope

## Encryption key
Self-hosted deployments must protect and back up the encryption key because encrypted credential data without the correct key is not operationally recoverable.

## External secret store
Prefer centralized secret management when organization size/risk warrants it.


---

# FILE: 06_SECURITY/03_rbac_projects.md

# RBAC and Project Boundaries

Permission questions:
- who can view?
- who can edit?
- who can execute?
- who can publish?
- who can use/share credentials?
- who can deploy?

## Important capability model
Ability to execute a workflow can effectively grant use of capabilities embedded in its credentials/tools. Workflow sharing is therefore a security decision.

## Project design
Split domains with different trust levels:
- CRM
- Scraping
- Finance
- Content
- Platform Admin


---

# FILE: 06_SECURITY/04_ssrf_network.md

# SSRF and Network Security

User-controlled URLs can become internal network probes.

Controls:
- SSRF protection
- allowlists for necessary internal endpoints
- firewall/network policy
- private service segmentation
- DNS considerations
- block cloud metadata endpoints
- do not rely on app-layer SSRF control alone

HTTP Request node deserves security review whenever URL is dynamic.


---

# FILE: 06_SECURITY/05_code_supply_chain.md

# Code and Supply-chain Security

## Code Node
Review:
- environment access
- network access
- filesystem
- infinite loops
- large memory usage
- unsafe eval/dynamic code

## Community/Custom Nodes
Review:
- publisher
- source
- package dependencies
- release history
- maintenance
- requested capabilities

Pin versions for critical deployments and test upgrades.


---

# FILE: 06_SECURITY/06_agent_security.md

# AI Agent Security

Threats:
- prompt injection
- tool abuse
- data exfiltration
- over-privileged tool
- hallucinated parameters
- malicious retrieved content

Controls:
- tool allowlist
- structured inputs
- policy layer
- approval for high-risk actions
- retrieval authorization
- output validation
- audit every side effect


---

# FILE: 07_RELIABILITY/01_error_taxonomy.md

# Error Taxonomy

## Transient
timeout/network/5xx → retry possible.

## Rate limited
429/quota → delayed retry.

## Authentication
401/token expiry → credential repair/refresh.

## Authorization
403 → no retry until permission changes.

## Validation
400/schema/business rule → correction required.

## Conflict/Duplicate
409/unique constraint → may be idempotent success or business conflict.

## Unknown
persist context → DLQ/manual review.


---

# FILE: 07_RELIABILITY/02_retry_backoff.md

# Retry and Backoff

Retry policy defines:
- eligible errors
- max attempts
- base delay
- exponential factor
- jitter
- max delay
- idempotency precondition

## Example
Attempt 1: immediate
Attempt 2: ~2s
Attempt 3: ~5s
Attempt 4: ~12s

Exact values depend on provider limits and workload.


---

# FILE: 07_RELIABILITY/03_dlq_reconciliation.md

# DLQ and Reconciliation

## DLQ record
- job_id
- workflow
- execution_id
- payload/reference
- error_class
- message
- retry_count
- first_failed_at
- last_failed_at
- status

## Reconciliation
A separate workflow periodically checks:
- stuck jobs
- outbox pending
- missing external state
- inconsistent DB records
- stale heartbeats

Recovery is a first-class workflow.


---

# FILE: 07_RELIABILITY/04_outbox_saga.md

# Outbox and Saga

## Outbox
Use when DB change and external message must not diverge.

Transaction:
1. update business row
2. insert outbox row
3. commit
4. dispatcher sends
5. mark delivered

## Saga
For multi-system process:
- action
- next action
- if failure → compensating action

Do not pretend distributed transactions exist when services do not share a transaction manager.


---

# FILE: 07_RELIABILITY/05_circuit_bulkhead.md

# Circuit Breaker and Bulkhead

## Circuit breaker
If dependency failure crosses threshold:
- open circuit
- stop calls
- cool down
- half-open probe
- close on recovery

## Bulkhead
Separate resource domains:
- CRM
- Scraping
- AI
- Media

A noisy scraper should not exhaust all capacity and block business-critical CRM work.


---

# FILE: 08_DATA/01_state_model.md

# State Model

Types of state:

## Platform state
n8n metadata/executions.

## Business state
customers, doctors, leads, orders, tasks.

## Job state
queued/running/checkpoint/progress.

## Agent state
session/memory/evaluation.

Keep ownership explicit. Do not mix these models.


---

# FILE: 08_DATA/02_postgres_design.md

# PostgreSQL Design

Production DB design:
- primary keys
- unique business keys
- indexes for lookup paths
- timestamps
- soft-delete only when business needs it
- audit for sensitive changes

## High-volume ingestion
- batch upsert
- indexes deliberately
- avoid per-row round-trip
- keep transaction size bounded


---

# FILE: 08_DATA/03_audit_model.md

# Business Audit Model

Suggested fields:
- id
- actor_type
- actor_id
- entity_type
- entity_id
- action
- before_json
- after_json
- reason
- correlation_id
- execution_id
- created_at

Audit is separate from technical execution logs.


---

# FILE: 08_DATA/04_job_table.md

# Job State Table Pattern

Suggested fields:
- job_id
- type
- status
- priority
- cursor
- processed_count
- failed_count
- retry_count
- last_execution_id
- heartbeat_at
- started_at
- finished_at
- error_summary

Execution is an attempt. Job is the business processing unit.


---

# FILE: 09_TESTING/01_test_pyramid.md

# Automation Test Pyramid

## Unit-like
Expressions, transforms, schema validators, code functions.

## Node integration
Real/sandbox API with known fixture.

## Workflow integration
Full path with test credentials.

## Regression
Known incidents converted to tests.

## Load
Concurrency/volume.

## Recovery
Force dependency failure and validate recovery.


---

# FILE: 09_TESTING/02_workflow_test_cases.md

# Workflow Test Case Template

- ID
- scenario
- preconditions
- input
- expected output
- expected side effects
- expected audit
- expected error behavior
- cleanup
- environment

Critical workflows need negative tests, not only happy path.


---

# FILE: 09_TESTING/03_agent_eval_dataset.md

# Agent Evaluation Dataset

For each case:
- user request
- context
- permitted tools
- expected tool choice
- expected arguments
- forbidden actions
- expected final state
- rubric

Include:
- ambiguous requests
- prompt injection
- tool failure
- missing permission
- duplicate action


---

# FILE: 09_TESTING/04_load_testing.md

# Load Testing

Measure:
- requests/sec
- execution throughput
- queue depth
- p50/p95/p99 latency
- worker CPU/RAM
- DB pool usage
- Redis latency
- external API throttling

Ramp gradually. Bottleneck must be identified before adding more workers.


---

# FILE: 10_DEVOPS/01_environments.md

# Environments

Recommended:
- dev
- staging
- production

Separate:
- credentials
- databases
- callback URLs
- secrets
- sample data
- external provider accounts when possible

Never test destructive production action with a flag hidden deep in a Code node.


---

# FILE: 10_DEVOPS/02_git_source_control.md

# Git and Source Control

Use Git for:
- review
- change history
- environment promotion
- rollback reference

Do not treat Git alone as full disaster recovery.

Review workflow:
dev save → validate → commit/push → PR → staging pull → test → prod promotion → publish.


---

# FILE: 10_DEVOPS/03_release_rollout.md

# Release and Rollout

## Pre-release
- backup
- migration review
- workflow tests
- security scan
- dependency check

## Rollout
- deploy exact version
- health/readiness
- smoke tests
- monitor errors/latency

## Rollback
Define:
- app rollback
- workflow rollback
- DB migration rollback/forward-fix
- credential/config restore


---

# FILE: 10_DEVOPS/04_backup_restore.md

# Backup and Restore

Backup scope:
- PostgreSQL
- workflow exports/source control
- encryption key
- environment/config
- custom nodes
- object storage as required
- secret manager configuration

A backup not restore-tested is only an assumption.

Run periodic restore drills in isolated environment.


---

# FILE: 10_DEVOPS/05_upgrade_playbook.md

# Upgrade Playbook

1. Read release/breaking changes.
2. Snapshot/backup.
3. Reproduce production topology in staging.
4. Upgrade staging.
5. Test:
   - webhook
   - schedule/poll
   - wait/resume
   - sub-workflow
   - queue/worker
   - code/task runner
   - agent/MCP
6. Run regression suite.
7. Roll out production.
8. Observe.


---

# FILE: 11_OBSERVABILITY/01_three_pillars.md

# Observability Model

## Metrics
Counts, latency, queue, CPU/RAM, DB pool.

## Logs
Structured technical events.

## Traces
Cross-component execution path.

## Business Audit
Separate fourth layer: who changed what and why.

Every incident should be diagnosable without opening every node manually.


---

# FILE: 11_OBSERVABILITY/02_slos.md

# SLOs for Automation

Examples:
- 99.9% webhook acceptance
- 99% jobs complete within 5 minutes
- <1% permanent failure
- 95% AI extraction accepted without correction

SLO must map to business importance, not vanity infrastructure metrics.


---

# FILE: 11_OBSERVABILITY/03_correlation.md

# Correlation and Traceability

Propagate:
- correlation_id
- job_id
- tenant_id
- entity_id
- source_event_id

Across:
webhook → parent workflow → sub-workflow → DB → outbox → external API.

This makes multi-workflow incidents reconstructable.


---

# FILE: 11_OBSERVABILITY/04_alerting.md

# Alerting

Alert on symptoms that need action:
- queue depth sustained
- failure rate spike
- stale jobs
- DB pool exhaustion
- credential/auth failures
- outbox backlog
- webhook 5xx
- agent unsafe-action rejection spike

Avoid alerts on every isolated transient error.


---

# FILE: 12_DEBUGGING/01_rca.md

# Root Cause Analysis

Order:
1. business symptom
2. correlation/job id
3. failing workflow/node
4. actual input
5. expected contract
6. external dependency state
7. credential/auth
8. DB state
9. runtime/system resources
10. version/change history

Fix root cause, then add prevention.


---

# FILE: 12_DEBUGGING/02_common_failures.md

# Common Failure Patterns

## Undefined field
Cause: upstream schema changed/missing field.
Fix: schema validation/default branch.

## 401
Cause: expired/wrong credential.
Fix: credential lifecycle, refresh, scope.

## 429
Cause: rate limit.
Fix: queue/backoff/concurrency.

## duplicate records
Cause: retry/event duplication.
Fix: idempotency/unique constraint.

## workflow hangs
Cause: long API, loop, wait, blocked dependency.
Fix: timeout, async split, batch limits.

## AI output parse error
Cause: free-form output.
Fix: structured schema + validator + fallback.


---

# FILE: 12_DEBUGGING/03_debug_record.md

# Debug Knowledge Record

Fields:
- signature
- error_class
- workflow_version
- node_type
- symptoms
- root_cause
- fix
- prevention
- regression_test_id
- affected_versions
- confidence


---

# FILE: 13_COST_SCALE/01_capacity_planning.md

# Capacity Planning

Estimate:
- executions/min
- average duration
- concurrency
- CPU-bound vs I/O-bound ratio
- DB queries/execution
- external calls/execution
- payload size

Then size:
- workers
- worker concurrency
- DB pool
- Redis
- network
- storage

Use measurement, not guessed universal numbers.


---

# FILE: 13_COST_SCALE/02_cost_model.md

# Cost Model

Track:
- n8n compute
- PostgreSQL
- Redis
- object storage
- API providers
- LLM tokens
- proxies/browser automation
- operational labor

Normalize to:
- cost/job
- cost/lead
- cost/customer action
- cost/1k executions


---

# FILE: 13_COST_SCALE/03_ai_cost.md

# AI Cost Optimization

Levers:
- use deterministic logic before LLM
- smaller model for classification/extraction
- larger model only for hard cases
- cache stable results
- batch when model/provider supports
- compress context
- retrieve only relevant chunks
- structured output to reduce retries

Optimize cost without sacrificing required accuracy.


---

# FILE: 14_GOVERNANCE/01_ownership.md

# Ownership

Every production workflow:
- business owner
- technical owner
- backup owner/team
- criticality
- lifecycle status
- review date

Orphaned workflow = operational risk.


---

# FILE: 14_GOVERNANCE/02_lifecycle.md

# Workflow Lifecycle

States:
Draft → Review → Approved → Production → Deprecated → Archived.

Transition gates:
- tests
- security
- documentation
- owner
- rollback

Delete only after dependency and audit review.


---

# FILE: 14_GOVERNANCE/03_change_control.md

# Change Control

High-risk changes require:
- change description
- affected systems
- risk
- test evidence
- rollout
- rollback
- approver

Emergency changes must still be documented after containment.


---

# FILE: 15_BLUEPRINTS/01_crm.md

# CRM Automation Blueprint

Modules:
- lead intake
- dedupe
- profile
- interactions
- followups
- tasks
- reporting
- AI assistant

Core tables:
- contacts/doctors
- interactions
- followups
- tasks
- audit_log
- jobs

Workflows:
1. `CRM.INGEST.LEAD`
2. `CRM.UPSERT.PROFILE`
3. `CRM.CREATE.FOLLOWUP`
4. `CRM.COMPLETE.TASK`
5. `CRM.REPORT.DAILY`
6. `CRM.ERROR.HANDLER`

Key controls:
idempotency, role permissions, audit, task SLA.


---

# FILE: 15_BLUEPRINTS/02_voice_crm.md

# Voice-to-CRM Blueprint

```text
Telegram/Upload
 ↓
Persist audio
 ↓
Transcription
 ↓
AI structured extraction
 ↓
Schema validation
 ↓
Confidence/risk check
 ↓
Human review if needed
 ↓
CRM update
 ↓
Task/followup
 ↓
Audit
```

Fields can include:
- person/entity
- interaction summary
- sentiment/intent if business-approved
- next action
- due date
- product/service interest
- relationship links

Never let free-form transcript directly mutate CRM.


---

# FILE: 15_BLUEPRINTS/03_scraper.md

# Scraping Platform Blueprint

Modules:
- job scheduler
- source adapter
- fetcher
- parser
- normalize
- dedupe
- enrich
- persist
- export
- compliance/retention

State:
job_id, source, cursor, processed, failed, heartbeat.

Scale:
separate queues/workers for slow external sources.

Data quality:
source_url, captured_at, confidence, raw_hash.


---

# FILE: 15_BLUEPRINTS/04_content_factory.md

# Content Factory Blueprint

Stages:
Idea → Research → Brief → Script → Asset → Edit → Approval → Publish → Analytics.

Each stage:
- owner
- SLA
- input/output contract
- attachments
- status transition
- audit

AI is useful for research/draft/classification; publishing remains deterministic with approval policy.


---

# FILE: 15_BLUEPRINTS/05_rag.md

# RAG Platform Blueprint

Ingestion:
source → parse → normalize → chunk → metadata → embed → index.

Query:
auth → retrieve authorized chunks → rerank → generate → citations → evaluate.

Ops:
- reindex strategy
- document version
- delete propagation
- freshness
- retrieval metrics


---

# FILE: 15_BLUEPRINTS/06_multi_agent.md

# Multi-Agent Blueprint

Roles:
- Supervisor: routing/coordination
- Architect: system design
- Builder: workflow artifact
- Debugger: incident RCA
- Security: policy/risk
- Reviewer: quality gate

Shared rules:
- no unrestricted mutual delegation
- explicit tool ownership
- bounded retries between agents
- shared correlation id
- final deterministic validation


---

# FILE: 16_TEMPLATES/01_workflow_spec_template.md

# Workflow Specification Template

## Identity
Name:
Version:
Owner:
Criticality:

## Business
Goal:
Success metric:

## Input
Schema:
Source:
Auth:

## Output
Schema:
Side effects:

## Runtime
Timeout:
Concurrency:
Retry:
Idempotency:

## Dependencies
APIs:
DB:
Files:
Models:

## Failure
Error classes:
DLQ:
Recovery:

## Observability
Metrics:
Correlation:
Alerts:

## Tests
Happy:
Negative:
Regression:
Load:


---

# FILE: 16_TEMPLATES/02_adr_template.md

# Architecture Decision Record

ID:
Title:
Date:
Status:

## Context
## Problem
## Constraints
## Options
## Decision
## Trade-offs
## Security impact
## Cost impact
## Migration
## Revisit trigger


---

# FILE: 16_TEMPLATES/03_incident_template.md

# Incident Record

ID:
Severity:
Started:
Resolved:
Owner:

## Impact
## Detection
## Timeline
## Root cause
## Contributing factors
## Recovery
## Data consistency checks
## Prevention actions
## Regression tests
## Follow-up owner/date


---

# FILE: 16_TEMPLATES/04_tool_contract.md

# Agent/MCP Tool Contract

Name:
Owner:
Purpose:
Risk tier:

Input schema:
Output schema:

Permissions:
Credentials:
Side effects:
Idempotency:
Timeout:
Errors:
Audit fields:
Approval required:
Examples:


---

# FILE: 17_PROMPTS/01_chief_architect.md

# Chief Architect Agent

Mission:
Turn business requirements into secure, reliable n8n architectures.

Process:
1. classify workload/risk/scale.
2. identify authoritative data/state.
3. define system boundaries.
4. choose patterns.
5. define workflow contracts.
6. specify security/reliability.
7. produce implementation map.
8. run quality gate.

Never start by listing nodes.


---

# FILE: 17_PROMPTS/02_builder.md

# Builder Agent

Input: approved architecture + workflow spec.

Responsibilities:
- map spec to n8n nodes/sub-workflows.
- preserve contracts.
- avoid hard-coded secrets.
- create error paths.
- produce version-sensitive notes.
- validate JSON shape before delivery.

Reject ambiguous destructive behavior rather than inventing it.


---

# FILE: 17_PROMPTS/03_debugger.md

# Debugger Agent

Use evidence-first debugging.

Order:
symptom → execution/job id → failing contract → node input/output → dependency → credential → state → runtime.

Return:
- root cause
- evidence
- minimal fix
- recovery steps
- prevention test


---

# FILE: 17_PROMPTS/04_security_reviewer.md

# Security Reviewer Agent

Review:
- public surface
- auth
- credentials/scopes
- dynamic URLs/SSRF
- code/community nodes
- SQL/input injection
- agent tools
- file handling
- audit/retention

Return prioritized findings:
Critical / High / Medium / Low with remediation.


---

# FILE: 17_PROMPTS/05_optimizer.md

# Optimizer Agent

Optimize without changing business semantics.

Check:
- redundant calls
- per-item loops
- duplicated transforms
- LLM overuse
- DB query patterns
- queue/concurrency
- payload size
- retries

Every optimization must state expected benefit and regression risk.


---

# FILE: 18_JSON_EXAMPLES/README.md

# JSON Examples

این JSONها آموزشی هستند و باید روی نسخه هدف n8n validate شوند، چون typeVersion و schema Nodeها ممکن است تغییر کند.

Included:
- `example_webhook_validate_respond.json`

هدف این پوشه نشان دادن shape، naming و contract است؛ نه تضمین سازگاری ابدی با همه نسخه‌ها.


---

# FILE: 19_CHECKLISTS/01_production_readiness.md

# Production Readiness Checklist

- [ ] Business owner مشخص
- [ ] Technical owner مشخص
- [ ] Input/output contract
- [ ] Authentication
- [ ] Secret handling
- [ ] Timeout
- [ ] Retry classification
- [ ] Idempotency
- [ ] Error workflow
- [ ] DLQ/recovery if critical
- [ ] Correlation id
- [ ] Audit where needed
- [ ] Metrics/alerts
- [ ] Backup/restore
- [ ] Regression tests
- [ ] Rollback plan
- [ ] Version pinned


---

# FILE: 19_CHECKLISTS/02_security_review.md

# Security Review Checklist

- [ ] Public webhook authenticated/signed
- [ ] Dynamic URL reviewed for SSRF
- [ ] Credentials least privilege
- [ ] No secrets in JSON/prompts
- [ ] Code/community nodes audited
- [ ] SQL parameterized
- [ ] File upload validated
- [ ] Agent tools allowlisted
- [ ] High-risk actions approved
- [ ] Sensitive data retention defined
- [ ] Logs do not leak secrets


---

# FILE: 19_CHECKLISTS/03_workflow_review.md

# Workflow Review Checklist

- [ ] Purpose clear
- [ ] Node names meaningful
- [ ] No giant hidden expression logic
- [ ] Reusable domain logic modularized
- [ ] Failure branches explicit
- [ ] Duplicate behavior defined
- [ ] External dependencies documented
- [ ] Business state durable
- [ ] Execution data not abused as database
- [ ] Version/change notes present


---

# FILE: 19_CHECKLISTS/04_agent_review.md

# Agent Review Checklist

- [ ] Agent needed vs deterministic workflow
- [ ] Tools narrow/scoped
- [ ] Structured output
- [ ] Schema validation
- [ ] Prompt injection considered
- [ ] Retrieved data authorized
- [ ] High-risk action approval
- [ ] Evaluation dataset
- [ ] Cost/latency budget
- [ ] Audit trail


---

# FILE: 20_SOURCES/README.md

# Sources and Provenance

این Repository بر اساس سه لایه ساخته شده است:

1. ساختار و مفاهیم موجود در v55 اولیه و روند توسعه v1 تا v55 در همین پروژه.
2. دانش مهندسی عمومی درباره distributed systems، security، reliability، databases و AI agents.
3. بررسی مستندات رسمی n8n برای مفاهیم متغیر نسخه‌ای در طول تحقیق این پروژه.

## Important

- جزئیات دقیق configuration/env vars و Node typeVersionها version-sensitive هستند.
- JSON examples باید روی target n8n instance validate شوند.
- قابلیت‌های Enterprise/plan-specific ممکن است در deployment شما موجود نباشند.
- این Repository عمداً بین «business state»، «n8n internal state» و «agent memory» تمایز می‌گذارد.

## Recommended Official Reference

برای هر استقرار واقعی، آخرین مستندات رسمی n8n و release/breaking changes همان نسخه هدف را مرجع نهایی قرار دهید.


---

# FILE: 20_SOURCES/VERSION_SENSITIVE_FACTS.md

# Version-sensitive Facts

موارد زیر قبل از اجرای Production باید روی نسخه نصب‌شده verify شوند:

- نام و default Environment Variableها
- typeVersion Nodeها
- Queue/Worker behavior
- Task Runner behavior
- Source Control/Projects/RBAC availability
- MCP feature set
- AI evaluation features
- Security audit/SSRF settings
- Metrics/OpenTelemetry support
- Workflow save/publish semantics
- Scheduler behavior


---

# FILE: INDEX.md

# File Index

- `00_CORE/01_architect_identity.md`
- `00_CORE/02_principles.md`
- `00_CORE/03_decision_framework.md`
- `00_CORE/04_architecture_scoring.md`
- `01_RUNTIME/01_execution_model.md`
- `01_RUNTIME/02_queue_mode.md`
- `01_RUNTIME/03_task_runners.md`
- `01_RUNTIME/04_webhooks_and_async.md`
- `01_RUNTIME/05_binary_files.md`
- `01_RUNTIME/06_timeouts_graceful_shutdown.md`
- `02_WORKFLOW_ENGINEERING/01_contracts.md`
- `02_WORKFLOW_ENGINEERING/02_modularity.md`
- `02_WORKFLOW_ENGINEERING/03_patterns.md`
- `02_WORKFLOW_ENGINEERING/04_anti_patterns.md`
- `02_WORKFLOW_ENGINEERING/05_naming_structure.md`
- `02_WORKFLOW_ENGINEERING/06_idempotency_design.md`
- `03_NODE_INTELLIGENCE/01_selection_matrix.md`
- `03_NODE_INTELLIGENCE/02_core_nodes.md`
- `03_NODE_INTELLIGENCE/03_database_nodes.md`
- `03_NODE_INTELLIGENCE/04_ai_nodes.md`
- `03_NODE_INTELLIGENCE/05_custom_nodes.md`
- `04_INTEGRATIONS/01_api_engineering.md`
- `04_INTEGRATIONS/02_webhook_security.md`
- `04_INTEGRATIONS/03_pagination_checkpoint.md`
- `04_INTEGRATIONS/04_files_and_storage.md`
- `05_AI_AGENT_MCP/01_agent_architecture.md`
- `05_AI_AGENT_MCP/02_tool_design.md`
- `05_AI_AGENT_MCP/03_memory.md`
- `05_AI_AGENT_MCP/04_rag.md`
- `05_AI_AGENT_MCP/05_mcp.md`
- `05_AI_AGENT_MCP/06_agent_evaluation.md`
- `06_SECURITY/01_threat_model.md`
- `06_SECURITY/02_credentials_secrets.md`
- `06_SECURITY/03_rbac_projects.md`
- `06_SECURITY/04_ssrf_network.md`
- `06_SECURITY/05_code_supply_chain.md`
- `06_SECURITY/06_agent_security.md`
- `07_RELIABILITY/01_error_taxonomy.md`
- `07_RELIABILITY/02_retry_backoff.md`
- `07_RELIABILITY/03_dlq_reconciliation.md`
- `07_RELIABILITY/04_outbox_saga.md`
- `07_RELIABILITY/05_circuit_bulkhead.md`
- `08_DATA/01_state_model.md`
- `08_DATA/02_postgres_design.md`
- `08_DATA/03_audit_model.md`
- `08_DATA/04_job_table.md`
- `09_TESTING/01_test_pyramid.md`
- `09_TESTING/02_workflow_test_cases.md`
- `09_TESTING/03_agent_eval_dataset.md`
- `09_TESTING/04_load_testing.md`
- `10_DEVOPS/01_environments.md`
- `10_DEVOPS/02_git_source_control.md`
- `10_DEVOPS/03_release_rollout.md`
- `10_DEVOPS/04_backup_restore.md`
- `10_DEVOPS/05_upgrade_playbook.md`
- `11_OBSERVABILITY/01_three_pillars.md`
- `11_OBSERVABILITY/02_slos.md`
- `11_OBSERVABILITY/03_correlation.md`
- `11_OBSERVABILITY/04_alerting.md`
- `12_DEBUGGING/01_rca.md`
- `12_DEBUGGING/02_common_failures.md`
- `12_DEBUGGING/03_debug_record.md`
- `13_COST_SCALE/01_capacity_planning.md`
- `13_COST_SCALE/02_cost_model.md`
- `13_COST_SCALE/03_ai_cost.md`
- `14_GOVERNANCE/01_ownership.md`
- `14_GOVERNANCE/02_lifecycle.md`
- `14_GOVERNANCE/03_change_control.md`
- `15_BLUEPRINTS/01_crm.md`
- `15_BLUEPRINTS/02_voice_crm.md`
- `15_BLUEPRINTS/03_scraper.md`
- `15_BLUEPRINTS/04_content_factory.md`
- `15_BLUEPRINTS/05_rag.md`
- `15_BLUEPRINTS/06_multi_agent.md`
- `16_TEMPLATES/01_workflow_spec_template.md`
- `16_TEMPLATES/02_adr_template.md`
- `16_TEMPLATES/03_incident_template.md`
- `16_TEMPLATES/04_tool_contract.md`
- `17_PROMPTS/01_chief_architect.md`
- `17_PROMPTS/02_builder.md`
- `17_PROMPTS/03_debugger.md`
- `17_PROMPTS/04_security_reviewer.md`
- `17_PROMPTS/05_optimizer.md`
- `18_JSON_EXAMPLES/README.md`
- `18_JSON_EXAMPLES/example_webhook_validate_respond.json`
- `19_CHECKLISTS/01_production_readiness.md`
- `19_CHECKLISTS/02_security_review.md`
- `19_CHECKLISTS/03_workflow_review.md`
- `19_CHECKLISTS/04_agent_review.md`
- `20_SOURCES/README.md`
- `20_SOURCES/VERSION_SENSITIVE_FACTS.md`
- `README.md`
- `SKILL.md`


---

# FILE: README.md

# n8n Architect Intelligence Engine v55 — ULTIMATE COMPLETE

نسخه جامع و محتوگذاری‌شده‌ی سیستم دانش برای طراحی، ساخت، بررسی، دیباگ، استقرار و بهبود سامانه‌های n8n در سطح Production.

## هدف

این Repository قرار نیست فقط «راهنمای استفاده از Nodeها» باشد. نقش آن ایجاد یک مرجع مهندسی برای Agent یا Engineer است تا بتواند:

- نیاز کسب‌وکار را به معماری تبدیل کند.
- Workflow را به اجزای کوچک، تست‌پذیر و قابل نگهداری تقسیم کند.
- n8n را در حالت single-instance یا distributed/queue-mode معماری کند.
- API، Webhook، Database، Queue، Files و AI Agentها را ایمن و قابل اتکا یکپارچه کند.
- Failure Modeها را قبل از Production طراحی کند.
- Workflow را از نظر امنیت، performance، cost و maintainability ارزیابی کند.
- Executionها را trace، diagnose و recover کند.
- AI Agent و MCP Toolها را با اصل least privilege طراحی کند.
- CI/CD، versioning، rollout و rollback را مدیریت کند.
- از خطاها و executionهای واقعی Knowledge تولید کند.

## مدل ذهنی پایه

```text
Business Goal
    ↓
Domain Model
    ↓
Architecture
    ↓
Workflow Contracts
    ↓
Implementation
    ↓
Testing
    ↓
Deployment
    ↓
Observability
    ↓
Recovery
    ↓
Learning
```

## اصول غیرقابل مذاکره

1. Business state با n8n execution history یکی نیست.
2. Agent جای deterministic workflow را نمی‌گیرد؛ Agent تصمیم می‌گیرد، workflow اقدام کنترل‌شده انجام می‌دهد.
3. هر side effect مهم باید idempotent یا دارای idempotency key باشد.
4. هر integration خارجی باید timeout، retry policy و failure classification داشته باشد.
5. هر workflow حیاتی باید owner، version، contract، error path، audit و rollback داشته باشد.
6. Code Node و Community Node باید به‌عنوان سطح ریسک جداگانه بررسی شوند.
7. محیط Production نباید محل توسعه تصادفی باشد.
8. «Workflow اجرا شد» برابر «سیستم درست است» نیست؛ صحت business outcome باید اندازه‌گیری شود.
9. Observability بخشی از معماری است، نه افزونه‌ی بعدی.
10. هر قابلیت Agent باید به کوچک‌ترین Tool لازم محدود شود.

## ساختار Repository

- `00_CORE`: هویت، اصول، مدل تصمیم‌گیری.
- `01_RUNTIME`: معماری execution و scale.
- `02_WORKFLOW_ENGINEERING`: طراحی Workflow و contracts.
- `03_NODE_INTELLIGENCE`: انتخاب و ارزیابی Node.
- `04_INTEGRATIONS`: API/Webhook/DB/File integration.
- `05_AI_AGENT_MCP`: Agent، Memory، RAG، MCP.
- `06_SECURITY`: مدل امنیت و hardening.
- `07_RELIABILITY`: retry، idempotency، DLQ، recovery.
- `08_DATA`: data contracts، DB، audit، state.
- `09_TESTING`: unit/integration/regression/evaluation.
- `10_DEVOPS`: Git، environments، release، rollback.
- `11_OBSERVABILITY`: metrics/logs/traces/SLO.
- `12_DEBUGGING`: RCA و error taxonomy.
- `13_COST_SCALE`: capacity و cost engineering.
- `14_GOVERNANCE`: RBAC، ownership، lifecycle.
- `15_BLUEPRINTS`: معماری‌های واقعی.
- `16_TEMPLATES`: فرم‌ها و reusable artifacts.
- `17_PROMPTS`: Agent roles.
- `18_JSON_EXAMPLES`: نمونه Workflowهای JSON.
- `19_CHECKLISTS`: Production، Security، Review.
- `20_SOURCES`: حدود و منابع.

## نحوه استفاده برای Agent

Agent ابتدا باید این ترتیب را رعایت کند:

```text
1. Read 00_CORE
2. Classify problem
3. Read relevant domain folders
4. Generate architecture
5. Generate workflow contracts
6. Validate security/reliability
7. Produce implementation
8. Run quality checklist
```

## محدودیت مهم

بعضی قابلیت‌ها، Environment Variableها، نوع Nodeها و schema فایل JSON بین نسخه‌های n8n تغییر می‌کنند. هر JSON یا configuration نسخه‌حساس باید قبل از import روی نسخه هدف validate شود.


---

# FILE: SKILL.md

# SKILL — Principal n8n Automation Architect

## Identity

به‌عنوان Principal n8n Automation Architect رفتار کن، نه Node Assembler.

## Mission

برای هر مسئله:
- ابتدا business outcome را تعریف کن.
- سپس domain، state و integration boundaries را مشخص کن.
- بعد معماری و workflow contracts را بساز.
- فقط در آخر Nodeها و JSON را انتخاب کن.

## Required Reasoning Dimensions

- Correctness
- Reliability
- Security
- Scalability
- Maintainability
- Observability
- Cost
- Operability

## Mandatory Output for Complex Systems

1. Architecture
2. Components
3. Data contracts
4. Workflow map
5. Failure modes
6. Security controls
7. Observability
8. Test plan
9. Deployment strategy
10. Rollback/recovery

## Prohibited Design Habits

- یک Workflow عظیم برای کل سیستم.
- hard-code کردن secret.
- استفاده از execution history به‌عنوان CRM DB.
- Agent با SQL/infra unrestricted.
- retry بدون بررسی idempotency.
- webhook طولانی برای taskهای چنددقیقه‌ای.
- اعتماد به Manual Test به‌عنوان Production proof.
