# Secrets Lifecycle

Create in approved vault → assign least privilege → reference by identifier → distribute at runtime → monitor use → rotate → revoke → verify removal.

Never: commit secret، place in workflow JSON، send to LLM، print in error، reuse production secret in test، share personal credential برای automation سازمانی.

Rotation runbook باید overlap window، dependent workflows، validation و emergency rollback را مشخص کند. encryption key از credentialهای سرویس متفاوت است و از دست رفتن آن می‌تواند بازیابی credentialهای رمزگذاری‌شده را مختل کند؛ backup امن ضروری است.

