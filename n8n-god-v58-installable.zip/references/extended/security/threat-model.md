# Threat Model

## Trust Boundaries

Internet ↔ reverse proxy ↔ n8n main/webhook ↔ queue/workers ↔ DB/Redis/object storage ↔ external APIs/LLMs ↔ users/approvers.

## STRIDE-focused threats

- Spoofing: forged webhook، stolen API key؛ کنترل: signature، nonce، timestamp، rotation.
- Tampering: modified payload/workflow؛ کنترل: hash، source control، protected prod، audit.
- Repudiation: بدون actor trail؛ کنترل: immutable decision/release record.
- Information disclosure: execution logs/secrets؛ کنترل: redaction، encryption، retention، RBAC.
- Denial of service: webhook flood/agent loop؛ کنترل: WAF، rate limit، queue، budgets، timeouts.
- Elevation: risky node/community package/tool؛ کنترل: allowlist، isolation، least privilege، review.

## AI-specific

Prompt injection، tool argument injection، retrieval poisoning، cross-tenant memory، model exfiltration و excessive agency. دفاع چندلایه است؛ هیچ prompt واحدی مرز امنیتی محسوب نمی‌شود.

