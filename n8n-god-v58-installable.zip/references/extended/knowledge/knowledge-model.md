# Automation Knowledge Model

## Record types

Requirement، Decision، Pattern، Workflow، NodeCapability، ConnectorLimit، Incident، Fix، Benchmark، Evaluation، Policy و Runbook.

## Mandatory metadata

ID، tenant، source، author/agent، created/updated، version، validity window، confidence، evidence level، classification، related artifacts و supersedes.

## Learning rules

- Incident fix پس از verification به reusable pattern تبدیل شود.
- model-generated claim بدون source به fact تبدیل نشود.
- نسخه جدید docs رکورد قدیمی را حذف نمی‌کند؛ supersede می‌کند.
- feedback کاربر با context و outcome ذخیره شود.
- policy و security findings از content retrieval قابل override نیستند.

