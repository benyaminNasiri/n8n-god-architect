# Production Gates

## G0 Intake

Require business outcome, service owner, incident owner, data classification, target version, deployment type, Edition, scale, SLO, RPO/RTO and acceptance criteria.

## G1 Architecture

Require bounded workflows, durable state, idempotency, classified failure modes, trust boundaries, backpressure and an ADR for material tradeoffs.

## G2 Static validation

Require valid JSON, graph references, node versions, credential references, secret scan, explicit settings, unique webhook paths and artifact hashes.

## G3 Functional evidence

Require fixtures for normal, boundary, duplicate, malformed and adversarial input. Preserve execution IDs and asserted business outcomes.

## G4 Security

Require least privilege, authenticated sensitive webhooks, replay controls, rate limits, redaction, retention, tenant isolation, dependency allowlists and approval policy.

## G5 Reliability

Inject 429, 5xx, timeout, invalid output, dependency outage, stale lock and unknown-outcome write. Prove bounded retry, DLQ, reconciliation, restore and rollback.

## G6 Performance and cost

Run representative steady and burst load. Record p50/p95/p99, queue age, worker saturation, database connections, dependency quota and cost per completed business outcome.

## G7 Approval

Require immutable release manifest, artifact hashes, backup, rollback target, service-owner approval, security approval and named observation owner.

## G8 Smoke

After deployment, execute a synthetic transaction and verify durable state plus downstream business effect, not only HTTP or execution success.

## G9 Observation

Observe at least one representative peak window. Close only when SLO, correctness, duplicate rate, DLQ and cost remain within limits.

## Verdict rules

- Any failed gate blocks Production activation.
- Conditional gates need an owner and deadline.
- E5 plus score ≥85, Security ≥80%, Reliability ≥80% and no hard blocker permits `Production-ready`.
- E6 permits `Production-proven` only after the observation window.
