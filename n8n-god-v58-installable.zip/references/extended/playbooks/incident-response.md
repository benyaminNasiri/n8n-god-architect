# Incident Response Playbook

1. Declare severity and incident commander.
2. Preserve execution IDs، logs، deployment hash و timestamps.
3. Stop impact: pause trigger، open circuit، reduce concurrency یا rollback.
4. Verify side effects before replay.
5. Recover from known checkpoint/DLQ.
6. Validate data correctness, not only green execution.
7. Communicate impact and status.
8. RCA within defined window.
9. Assign corrective actions and regression tests.

Never delete failed executions before evidence capture. Never bulk retry unknown-outcome writes without reconciliation.

