# Release and Rollback Playbook

Pre-release: artifact hash، compatibility، approvals، backup، migrations، rollback target، dashboards.

Deploy: limit blast radius، publish immutable version، run synthetic smoke، watch queue/error/latency/correctness.

Rollback triggers: critical security finding، duplicate side effect، sustained burn rate، data corruption، irreversible cost anomaly.

Rollback: disable new intake if required، restore previous workflow version، revert compatible config، reconcile in-flight executions، validate downstream state، document incident.

