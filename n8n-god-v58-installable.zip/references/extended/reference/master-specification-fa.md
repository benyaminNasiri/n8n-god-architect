# Master Specification — n8n Architect Intelligence Engine v58

## هدف نهایی

ایجاد یک Control Plane هوشمند که بتواند نیاز کسب‌وکار را تحلیل کند، معماری پیشنهاد دهد، Workflow تولید کند، آن را با شواهد آزمایش کند، ریسک را کنترل کند، انتشار را مدیریت کند و از داده عملیات برای بهبود بعدی استفاده کند؛ بدون اینکه محدودیت نسخه، Edition، مجوز، امنیت یا واقعیت اتصال‌ها را جعل کند.

## قابلیت‌های سیستم

### Architecture Intelligence

- decomposition فرایند به bounded workflowها؛
- انتخاب event-driven، scheduled، batch، queue یا human-task؛
- تحلیل consistency، ordering، concurrency و backpressure؛
- طراحی sync/async boundary؛
- انتخاب storage و state strategy؛
- تولید ADR و threat model.

### Workflow Intelligence

- تولید manifest و JSON candidate؛
- بررسی graph، node references، expressions و credentials؛
- ساخت sub-workflow contract؛
- طراحی idempotency، retry، circuit breaker، DLQ و reconciliation؛
- versioning رویدادها و migration داده.

### AI Intelligence

- تفکیک chain، classifier، extractor، RAG و agent؛
- tool allowlist، schema validation و approval؛
- prompt injection defense؛
- evaluation dataset و regression gate؛
- token، latency و cost budgets.

### Operational Intelligence

- تعیین SLI/SLO و error budget؛
- dashboard و actionable alert؛
- capacity planning و load profile؛
- backup/restore و disaster recovery؛
- incident triage و RCA؛
- safe rollout، canary و rollback.

## Non-goals

- دورزدن کنترل‌های دسترسی یا محدودیت سرویس؛
- استخراج یا نمایش secret؛
- ادعای تست بدون execution evidence؛
- استفاده از Agent برای منطق قطعی ساده؛
- انتشار Production بدون policy و approval؛
- تضمین 100٪ برای سیستم وابسته به API، شبکه یا مدل احتمالاتی.

## State Machine مأموریت

`REQUESTED → DISCOVERING → DESIGNED → DRAFTED → VALIDATING → REVIEWED → APPROVED → DEPLOYING → OBSERVING → OPERATING`

حالت‌های انحرافی: `BLOCKED`, `REJECTED`, `ROLLING_BACK`, `INCIDENT`, `RETIRED`.

هر transition باید actor، evidence، timestamp و policy decision داشته باشد.

## Evidence Levels

| سطح | معنی |
|---|---|
| E0 | ادعا یا فرض |
| E1 | مستندات رسمی |
| E2 | static validation |
| E3 | fixture/unit execution |
| E4 | integration execution در sandbox |
| E5 | staging E2E/load/security evidence |
| E6 | production telemetry طی observation window |

برچسب Production-ready حداقل به E5 نیاز دارد؛ Production-proven به E6.

## Quality Gates

G0 Intake completeness؛ G1 Architecture review؛ G2 Static validation؛ G3 Test pass؛ G4 Security؛ G5 Reliability؛ G6 Cost؛ G7 Approval؛ G8 Post-deploy smoke؛ G9 Observation closure.

هر Gate سه خروجی دارد: `pass`, `conditional`, `fail`. شرط‌ها باید owner و deadline داشته باشند.

## معماری مرجع Control Plane

1. Intake API/UI
2. Requirement normalizer
3. Planner/Chief Architect
4. Specialist agents
5. Artifact store
6. Policy engine
7. Validation runners
8. n8n adapter/API/MCP
9. Approval service
10. Telemetry collector
11. Knowledge store
12. Evaluation service

## مدل داده مرکزی

- Project
- Requirement
- Decision/ADR
- WorkflowArtifact
- Environment
- CredentialReference
- TestCase/TestRun
- PolicyDecision
- Release
- ExecutionEvidence
- Incident
- KnowledgeItem
- CostRecord

تمام رکوردها tenant، owner، classification، version و timestamps دارند.

## Handoff Protocol

هر Agent خروجی خود را با این Envelope تحویل می‌دهد:

```json
{
  "task_id": "...",
  "agent": "security",
  "status": "complete|blocked|failed",
  "facts": [],
  "assumptions": [],
  "artifacts": [],
  "findings": [],
  "risks": [],
  "required_actions": [],
  "evidence_level": "E0-E6",
  "confidence": 0.0
}
```

## Rule of Truth

System must never convert absence of evidence into evidence of success. «JSON ساخته شد» مساوی «Workflow کار می‌کند» نیست؛ «API call accepted» مساوی «business outcome completed» نیست؛ «execution succeeded» مساوی «side effect صحیح و بدون duplicate» نیست.

## Artifact Factory v58

هر پروژه ساخت یا Productionization باید حداقل یک Workflow candidate، manifest، evidence ledger و خروجی validator داشته باشد. پروژه‌های Production علاوه بر آن به release manifest، artifact hash، rollback، smoke test، SLO، alert و runbook نیاز دارند.

ابزارهای قطعی Skill برای این چرخه:

- `validate_workflow.py`: بررسی JSON، graph، node version، credential reference، webhook path، retry و secret؛
- `score_readiness.py`: محاسبه امتیاز و جلوگیری از برچسب Production بدون E5؛
- `build_release_bundle.py`: ساخت ZIP قطعی همراه `MANIFEST.sha256` و حذف فایل‌های حساس؛
- `validate_package.py`: کنترل سلامت خود Skill.

خروجی ابزار جای Integration Test را نمی‌گیرد. موفقیت validator فقط E2 است.
