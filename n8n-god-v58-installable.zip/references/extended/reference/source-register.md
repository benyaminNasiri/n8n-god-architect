# Source Register

Research date: 2026-09-22

## Official n8n

- Docs index: https://docs.n8n.io/
- Queue mode: https://docs.n8n.io/hosting/scaling/queue-mode/
- Concurrency: https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling/control-concurrency/
- Execution data: https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling/manage-execution-data/
- External binary storage: https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling/use-external-storage/
- Monitoring: https://docs.n8n.io/hosting/logging-monitoring/monitoring/
- OpenTelemetry configuration: https://docs.n8n.io/deploy/host-n8n/configure-n8n/basic-configuration/use-environment-variables/opentelemetry
- Security audit: https://docs.n8n.io/hosting/securing/security-audit/
- External secrets: https://docs.n8n.io/external-secrets/
- Security environment variables: https://docs.n8n.io/hosting/configuration/environment-variables/security/
- Task runners: https://docs.n8n.io/hosting/configuration/task-runners/
- Task runner hardening: https://docs.n8n.io/hosting/securing/hardening-task-runners/
- n8n 2.0 breaking changes: https://docs.n8n.io/2-0-breaking-changes/
- Webhook URLs behind reverse proxy: https://docs.n8n.io/hosting/configuration/configuration-examples/webhook-url/
- Workflow history: https://docs.n8n.io/build/manage-workflows/view-change-history
- Source control: https://docs.n8n.io/deploy/host-n8n/configure-n8n/basic-configuration/use-environment-variables/source-control
- AI Agent: https://docs.n8n.io/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.agent/
- Guardrails: https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.guardrails
- AI testing: https://docs.n8n.io/build/integrate-ai/test-and-improve-ai-workflows/understand-why-to-test
- Human approval: https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools/
- MCP: https://docs.n8n.io/connect/connect-to-n8n-mcp-server

## Standards/primary references

- OpenTelemetry: https://opentelemetry.io/docs/
- JSON Schema 2020-12: https://json-schema.org/draft/2020-12

نسخه و Edition مقصد باید در زمان اجرا دوباره بررسی شود؛ مستندات و قابلیت‌ها تغییر می‌کنند.
