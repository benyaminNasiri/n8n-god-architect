# Version and Edition Compatibility

## قانون

پیش از تولید JSON باید نسخه دقیق n8n، deployment type و Edition مشخص شود. Node typeVersion، parameterها، AI capabilities، source control، RBAC، log streaming، external secrets و binary storage ممکن است میان نسخه/Edition متفاوت باشند.

## Probe Checklist

- `n8nVersion`
- Cloud یا self-hosted
- Community/registered/Enterprise plan
- available nodes و versions
- installed community/custom nodes
- database و execution mode
- queue/worker configuration
- binary data mode
- task runner mode
- API/MCP availability
- projects/RBAC/source-control availability

اگر probe انجام نشده باشد، خروجی باید `compatibility_status: unverified` داشته باشد و فقط Candidate تلقی شود.

