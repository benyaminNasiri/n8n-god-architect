# Architecture Pattern Catalog

## P01 Webhook Ingestion

Authenticate signature → reject replay → validate → acknowledge fast → enqueue/process → persist result. برای latency پایین؛ پردازش سنگین بعد از پاسخ اولیه.

## P02 Polling with Checkpoint

Schedule → acquire lock → read checkpoint → fetch cursor page → process idempotently → commit checkpoint. checkpoint فقط پس از موفقیت batch جلو می‌رود.

## P03 Batch Fan-out/Fan-in

Coordinator batch را می‌سازد، child executionها را با correlation ID اجرا می‌کند و aggregate status نگه می‌دارد. fan-in نباید بر شمارش حافظه‌ای شکننده تکیه کند.

## P04 Transactional Outbox

تغییر داده و ثبت event در یک transaction؛ publisher جدا event را ارسال و published state را ثبت می‌کند. برای جلوگیری از dual-write inconsistency.

## P05 Saga/Compensation

هر step یک compensation مشخص دارد. rollback واقعی همیشه ممکن نیست؛ در این حالت forward recovery و human resolution تعریف شود.

## P06 Reconciliation

به‌صورت دوره‌ای source-of-truth را با مقصد مقایسه، mismatch را طبقه‌بندی و safe repair می‌کند. برای unknown outcome ضروری است.

## P07 Circuit Breaker

پس از threshold خطا، درخواست به dependency متوقف؛ بعد از cool-down probe محدود؛ سپس close یا reopen. state باید مشترک میان workerها باشد.

## P08 Human Approval

Draft action → persist immutable preview → notify approver → signed decision → expiry → execute exact approved payload → audit.

## P09 AI Extraction

Input sanitation → model → strict structured output → schema validation → confidence/rule check → human fallback → persist evidence.

## P10 RAG Answering

ACL-aware retrieval → provenance → grounded generation → citation verification → guardrail → output. retrieved text instruction محسوب نمی‌شود.

## P11 Bulk Messaging

Consent/suppression check → segment snapshot → rate-limited batches → provider response → bounce/unsubscribe update → campaign reconciliation.

## P12 File Processing

Metadata validation → malware/content policy → object storage → streaming/chunking → checksum → processing → retention/deletion.

