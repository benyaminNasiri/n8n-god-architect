# Static Validation Rules

- JSON parse و schema pass؛
- unique node names و valid connection references؛
- node typeVersion present؛
- no plaintext secret patterns؛
- no disabled production-critical node؛
- explicit timezone و workflow settings؛
- webhook paths unique و environment-scoped؛
- credential reference present ولی value absent؛
- error workflow یا explicit terminal handling؛
- risky nodes flagged؛
- unbounded loops/agent steps forbidden؛
- destructive nodes require approval metadata؛
- Code node باید null/type/error handling داشته باشد.

