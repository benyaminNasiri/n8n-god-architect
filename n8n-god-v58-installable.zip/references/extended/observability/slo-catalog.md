# SLO Catalog

## Ingestion

SLI: accepted valid events / valid events sent. هدف نمونه: 99.9% در 30 روز.

## Completion

SLI: workflows reaching correct terminal outcome / accepted events. خطاهای business validation جدا گزارش شوند.

## Latency

p50/p95/p99 از received تا business completion؛ queue wait جدا از processing.

## Correctness

duplicate side effects، missing records، reconciliation mismatch و human correction rate.

## AI Quality

schema-valid outputs، grounded accuracy، escalation precision، unsafe tool attempt، cost/task.

Targetهای نمونه باید با criticality، dependency SLA و budget تنظیم شوند.

