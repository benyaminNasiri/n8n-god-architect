# Alert Catalog

| Alert | Signal | Severity | First action |
|---|---|---|---|
| Ingestion drop | rate below baseline | High | verify trigger/proxy |
| Failure burn | SLO burn rate | High | inspect top errors |
| Queue age | oldest job age | High | check workers/dependency |
| DLQ growth | count/age | Medium/High | classify terminal causes |
| Retry storm | retry ratio | High | circuit/open dependency |
| Duplicate effect | idempotency conflict | Critical | pause affected flow |
| Credential expiry | auth failures/expiry | High | rotation runbook |
| Cost anomaly | cost per task | Medium | model/API/retry breakdown |
| AI policy violation | blocked tool/output | High | preserve evidence |

