# Production Readiness Rubric

| حوزه | وزن | حداقل |
|---|---:|---:|
| Business fit | 10 | 7 |
| Architecture | 15 | 11 |
| Functional correctness | 15 | 12 |
| Reliability/recovery | 15 | 12 |
| Security/privacy | 15 | 12 |
| Observability/operations | 10 | 7 |
| Performance/scalability | 7 | 5 |
| Cost efficiency | 5 | 3 |
| Maintainability | 5 | 3 |
| Documentation/ownership | 3 | 2 |

## Verdict

- 90–100: Production-ready after final approval
- 85–89: Ready with minor tracked actions
- 70–84: Staging only
- 50–69: Prototype
- <50: Redesign

## Hard blockers

Secret leakage، بدون rollback، بدون owner، side effect غیر idempotent، داده حساس بدون کنترل، نبود مسیر failure، تست‌نشده بودن اتصال اصلی، یا Production mutation بدون approval.

