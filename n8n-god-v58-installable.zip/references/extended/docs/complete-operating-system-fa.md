# سیستم‌عامل کامل معماری هوشمند n8n

## 1. مأموریت

سیستم باید مسئله کسب‌وکار را به یک اکوسیستم اتوماسیون قابل‌اندازه‌گیری، امن، قابل نگهداری و قابل بازیابی تبدیل کند. معیار موفقیت صرفاً «اجرای بدون خطا» نیست؛ خروجی باید اثر کسب‌وکاری، قابلیت مشاهده، هزینه کنترل‌شده و مالکیت عملیاتی مشخص داشته باشد.

## 2. مرز واقعیت

این بسته سه چیز را فراهم می‌کند:

1. مدل تصمیم‌گیری و تقسیم مسئولیت؛
2. قراردادهای خروجی و گیت‌های کیفیت؛
3. الگوهای فنی برای ساخت و اداره Workflow.

این بسته بدون موارد زیر خودمختار نیست:

- دسترسی مجاز به n8n API یا MCP؛
- Credentialهای سرویس‌ها؛
- دیتابیس و حافظه پایدار؛
- محیط Dev/Staging/Production؛
- کانال Approval؛
- Monitoring و Incident ownership.

## 3. معماری لایه‌ای

### L0 — Business Control Plane

ورودی‌ها: هدف، KPI، مالک فرایند، محدودیت بودجه، SLA/SLO، طبقه‌بندی داده و تحمل ریسک.

خروجی‌ها: Business case، معیار پذیرش، دامنه و موارد خارج از دامنه.

### L1 — Strategy Intelligence

- تشخیص اینکه آیا اتوماسیون ارزش دارد یا نه؛
- تعیین Build/Buy/Manual؛
- محاسبه تقریبی حجم، هزینه، زمان و ریسک؛
- اولویت‌بندی با Impact × Confidence ÷ Effort/Risk.

### L2 — Architect Engine

- انتخاب Trigger و الگوی Orchestration؛
- تعریف bounded context و مالکیت داده؛
- تعیین همگام/ناهمگام بودن؛
- طراحی idempotency، retry، timeout، DLQ و reconciliation؛
- ثبت Architecture Decision Record.

### L3 — Agent Control Plane

Agent اصلی برنامه را می‌سازد و Agentهای تخصصی فقط در محدوده قرارداد خود عمل می‌کنند. هیچ Agentی نباید هم‌زمان سازنده و تأییدکننده نهایی همان تغییر باشد.

### L4 — Workflow Factory

نیاز را به Specification، Node graph، JSON، تست و Release candidate تبدیل می‌کند.

### L5 — Evaluation Plane

درستی، امنیت، قابلیت اطمینان، عملکرد، هزینه، نگهداشت‌پذیری و اثر کسب‌وکاری را اندازه می‌گیرد.

### L6 — Knowledge Plane

Requirementها، ADRها، Workflowها، Executionها، Incidentها، Fixها، Benchmarkها و درس‌آموخته‌ها را با نسخه و provenance نگهداری می‌کند.

### L7 — Governance Plane

Policy، Approval، RBAC، Audit، Data retention و Separation of duties را اعمال می‌کند.

### L8 — Operations Plane

Health، metrics، logs، tracing، alerting، backup، recovery و capacity را اداره می‌کند.

### L9 — Improvement Loop

فقط از شواهد تأییدشده یاد می‌گیرد. تغییر Prompt یا Policy بدون ارزیابی regression وارد Production نمی‌شود.

## 4. تیم Agentها و قرارداد مسئولیت

| Agent | مسئولیت | خروجی اجباری | ممنوعیت |
|---|---|---|---|
| Chief Architect | طراحی کل و تصمیم نهایی فنی | Solution Contract، ADR، topology | Deploy مستقیم بدون گیت |
| Strategy | ارزش، KPI و اولویت | Business case، baseline، target | ساخت Workflow |
| Builder | تولید JSON و مستندات | Importable JSON، mapping، tests | تغییر Credential واقعی |
| Debugger | تحلیل failure و root cause | RCA، reproduction، repair plan | حذف execution evidence |
| Security | Threat model و کنترل‌ها | risk register، approval matrix | پذیرش ریسک از طرف مالک |
| SRE/Operations | SLO، monitoring و recovery | dashboard spec، runbook | تغییر منطق کسب‌وکار |
| Cost Optimizer | کنترل مصرف API/AI/infra | cost model، budgets | کاهش کیفیت زیر acceptance |
| Reviewer | ارزیابی مستقل | scorecard، blockers | بازنویسی پنهانی خروجی Builder |

## 5. چرخه استاندارد اجرای مأموریت

### مرحله 1: Intake

حداقل داده لازم: هدف، Trigger، ورودی و خروجی، حجم، latency، سرویس‌ها، داده حساس، failure tolerance، بودجه و مالک.

### مرحله 2: Discovery

API limits، auth، webhooks، pagination، data contracts، availability و edition/license محدودیت‌های هر سرویس بررسی می‌شوند.

### مرحله 3: Design

خروجی طراحی شامل context diagram، sequence، data contract، error matrix، security model، observability و rollout plan است.

### مرحله 4: Build

Workflow باید نام‌گذاری پایدار، sub-workflowهای محدود، credential reference بدون secret، annotation و settings صریح داشته باشد.

### مرحله 5: Verify

Schema validation، static review، fixture tests، negative tests، integration tests، load test متناسب و security review اجرا می‌شود.

### مرحله 6: Release

Release از Dev به Staging و سپس Production حرکت می‌کند. نسخه، changelog، rollback target و approver ثبت می‌شوند.

### مرحله 7: Operate

SLO، alert، execution retention، runbook، on-call owner و recovery drills فعال می‌شوند.

### مرحله 8: Improve

داده Execution و Incident به پیشنهاد تغییر تبدیل می‌شود؛ پیشنهاد پس از regression evaluation و Approval منتشر می‌شود.

## 6. کلاس‌های خودمختاری

| سطح | رفتار مجاز |
|---|---|
| A0 Observe | خواندن metadata، log و metrics |
| A1 Recommend | تحلیل و پیشنهاد بدون تغییر |
| A2 Draft | ساخت JSON، patch و plan در محیط غیرعملیاتی |
| A3 Execute Safe | اجرای reversible در Dev/Staging |
| A4 Execute Controlled | تغییر Production با Approval و rollback |
| A5 Closed Loop | اصلاح محدود خودکار در policy از پیش تصویب‌شده |

اقدامات حذف داده، rotation credential، ارسال انبوه، تراکنش مالی، تغییر دسترسی و انتشار عمومی هرگز صرفاً با تصمیم مدل انجام نمی‌شوند.

## 7. قرارداد Solution

هر پروژه باید حداقل شامل این موارد باشد:

- `problem_statement`
- `business_outcome`
- `kpis`
- `scope` و `non_goals`
- `assumptions`
- `data_classification`
- `workflow_topology`
- `interfaces`
- `failure_modes`
- `security_controls`
- `test_plan`
- `deployment_plan`
- `rollback_plan`
- `observability`
- `cost_model`
- `owners`
- `open_risks`

Schema ماشین‌خوان در پوشه `schemas` قرار دارد.

## 8. Definition of Done

یک Workflow زمانی Done است که:

- معیار پذیرش کسب‌وکار پاس شده باشد؛
- هیچ secret داخل JSON نباشد؛
- مسیرهای retry، permanent failure و manual recovery مشخص باشند؛
- replay باعث duplicate side effect نشود؛
- تست‌های happy/negative/rate-limit/timeout اجرا شده باشند؛
- dashboard و alert قابل اقدام وجود داشته باشد؛
- مالک، runbook، rollback و retention تعیین شده باشند؛
- Production Readiness Score حداقل 85 و امتیاز Security و Reliability هرکدام حداقل 80 باشد؛
- هیچ blocker باز وجود نداشته باشد.

## 9. منابع رسمی تحقیق

- n8n Docs: https://docs.n8n.io/
- Scaling and queue mode: https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling/
- Queue mode: https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling/enable-queue-mode/
- Concurrency: https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling/control-concurrency/
- Source control environments: https://docs.n8n.io/source-control-environments/create-environments/
- Security audit: https://docs.n8n.io/hosting/securing/security-audit/
- External secrets: https://docs.n8n.io/external-secrets/
- Monitoring: https://docs.n8n.io/hosting/logging-monitoring/monitoring/
- Log streaming: https://docs.n8n.io/log-streaming/
- AI Agent: https://docs.n8n.io/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.agent/
- Human approval for tools: https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools/
- n8n MCP server: https://docs.n8n.io/connect/connect-to-n8n-mcp-server

قابلیت‌ها ممکن است بر اساس نسخه و Edition متفاوت باشند؛ پیش از اجرا باید با محیط مقصد تطبیق داده شوند.

