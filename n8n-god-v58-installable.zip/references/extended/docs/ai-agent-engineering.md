# مهندسی AI Agent در n8n

## Agent یا Workflow قطعی؟

اگر مسیر تصمیم قابل تعریف است، Workflow قطعی انتخاب اول است. Agent زمانی استفاده شود که انتخاب ابزار، تفسیر زبان طبیعی یا برنامه‌ریزی پویا ارزش واقعی ایجاد کند.

## Agent Loop

Goal → retrieve context → plan → select tool → validate arguments → policy check → execute/approve → observe → stop/evaluate.

حداکثر step، timeout، token budget، tool budget و termination condition اجباری هستند.

## Tool Contract

هر Tool باید نام روشن، توضیح محدود، JSON Schema، timeout، side-effect class، idempotency behavior، required permission و error schema داشته باشد.

## Memory

- Working memory: فقط همان execution؛
- Conversation memory: محدود به session و TTL؛
- Operational memory: incident/fix/benchmark ساختاریافته؛
- Knowledge base: اسناد نسخه‌دار با provenance؛
- Policy memory: فقط خواندنی برای Agent.

هر memory باید tenant scope، retention، deletion و PII policy داشته باشد. خروجی مدل بدون تأیید به‌عنوان fact پایدار ذخیره نمی‌شود.

## MCP

MCP سطح دسترسی جدید ایجاد نمی‌کند؛ فقط ابزار را در اختیار client قرار می‌دهد. server باید toolهای حداقلی، auth، audit، rate limit و approval داشته باشد. امکان نوشتن یا اجرا در Production جدا از امکان مشاهده تعریف شود.

## Human-in-the-loop

Approval payload باید شامل action، target، داده ارسالی، هزینه/ریسک، preview، expiry و گزینه approve/reject باشد. بعد از approval نیز Agent فقط همان action و arguments تأییدشده را اجرا می‌کند.

## Evaluation

مجموعه ارزیابی شامل نمونه‌های عادی، مبهم، adversarial، prompt injection، unavailable tool و conflicting instruction است.

معیارها:

- task success؛
- tool selection accuracy؛
- argument validity؛
- policy compliance؛
- hallucination/unsupported claim؛
- latency و cost؛
- human escalation precision؛
- side-effect correctness.

هر تغییر model، prompt، tool description یا retrieval نیازمند regression evaluation است.

