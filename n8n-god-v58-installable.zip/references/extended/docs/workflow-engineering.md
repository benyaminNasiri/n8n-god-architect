# مهندسی Workflow

## 1. اصول طراحی

1. یک Workflow، یک مسئولیت اصلی.
2. Trigger از processing و side effect جدا باشد.
3. داده ورودی در مرز سیستم validate و normalize شود.
4. هر side effect کلید idempotency داشته باشد.
5. Retry فقط برای خطای transient و همراه backoff+jitter باشد.
6. خطای permanent به quarantine/DLQ برود.
7. عملیات طولانی asynchronous و قابل resume باشد.
8. payload بزرگ خارج از execution state ذخیره و با reference منتقل شود.
9. credential با نام منطقی reference شود؛ secret داخل JSON ممنوع است.
10. هر Workflow یک owner، SLA، version و runbook دارد.

## 2. الگوی استاندارد Node Graph

`Trigger → Authenticate/Verify → Validate → Normalize → Idempotency Check → Process → Side Effect → Persist Outcome → Respond/Notify`

شاخه‌های مکمل:

- Transient error → retry policy → process
- Permanent error → DLQ/quarantine → alert
- Unknown outcome → reconciliation workflow
- Manual approval → pause → approve/reject/expire

## 3. Data Contract

Envelope پیشنهادی:

```json
{
  "event_id": "uuid",
  "event_type": "lead.created.v1",
  "occurred_at": "2026-09-22T00:00:00Z",
  "source": "service-name",
  "correlation_id": "uuid",
  "idempotency_key": "stable-business-key",
  "schema_version": 1,
  "data": {}
}
```

قواعد: زمان UTC، schema version صریح، شناسه correlation سرتاسری، PII حداقلی و fieldهای ناشناخته با policy مشخص.

## 4. Idempotency

- کلید باید از هویت رویداد یا عملیات کسب‌وکاری ساخته شود، نه زمان اجرا.
- قبل از side effect با unique constraint ثبت شود.
- حالت‌ها: `received`, `processing`, `succeeded`, `failed_retryable`, `failed_terminal`.
- پاسخ سرویس مقصد و external ID ذخیره شود.
- replay همان نتیجه قبلی را برگرداند یا safely resume کند.

## 5. Error Taxonomy

| نوع | مثال | رفتار |
|---|---|---|
| Validation | فیلد اجباری خالی | terminal، quarantine |
| Authentication | token منقضی | refresh یک‌بار، سپس alert |
| Authorization | scope ناکافی | terminal، security alert |
| Rate limit | HTTP 429 | Retry-After یا backoff+jitter |
| Transient upstream | 502/503/timeout | retry محدود |
| Conflict | duplicate/409 | reconcile/idempotent success |
| Unknown outcome | timeout بعد از POST | lookup/reconcile قبل از retry |
| Internal bug | expression/code error | stop، capture context، RCA |

## 6. Retry Policy

Retry budget محدود باشد. نمونه: 5 تلاش با delayهای 2، 5، 15، 45 و 120 ثانیه و jitter. `Retry-After` سرویس مقصد اولویت دارد. عملیات غیر-idempotent بدون reconciliation کورکورانه retry نمی‌شود.

## 7. Pagination و Rate Limits

- cursor بر offset ترجیح دارد؛
- cursor و checkpoint پایدار ذخیره شوند؛
- batch size قابل تنظیم باشد؛
- توقف و ادامه بدون پردازش مجدد امکان‌پذیر باشد؛
- limiter مشترک برای چند worker در Redis/DB نگهداری شود.

## 8. Sub-workflow

Sub-workflow برای قابلیت reusable با قرارداد ورودی/خروجی مشخص استفاده می‌شود؛ نه برای پنهان‌کردن پیچیدگی. depth، timeout و خطای propagation باید صریح باشند. circular invocation ممنوع است.

## 9. Testing Pyramid

- Static: JSON، references، disabled nodes، secrets، naming.
- Contract: schema ورودی/خروجی و fixture.
- Node/logic: expressions و Code node.
- Integration: sandbox سرویس خارجی.
- End-to-end: مسیر واقعی Staging.
- Resilience: 429، 5xx، timeout، malformed payload، duplicate event.
- Load: نرخ هدف، burst، queue depth و memory.
- Recovery: retry، replay، DLQ و restore.

## 10. Naming

Workflow: `[domain].[capability].[trigger].[env].vN`

Node: فعل + موجودیت، مانند `Validate Lead`, `Create CRM Contact`.

Credential: `[service]-[purpose]-[env]-[owner]` بدون درج secret یا نام شخص غیرضروری.

