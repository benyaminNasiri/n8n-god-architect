# استقرار و عملیات

## Topology

### کوچک

n8n + PostgreSQL + reverse proxy. برای بار کم و Workflowهای غیرحیاتی.

### Production متوسط/بزرگ

- main/webhook instances؛
- PostgreSQL پایدار؛
- Redis و queue mode؛
- workerهای افقی؛
- task runner متناسب با حالت اجرا؛
- object storage برای binary data در صورت نیاز؛
- load balancer، metrics، centralized logs و backup.

Queue mode طبق مستندات رسمی مسیر اصلی scale افقی است. تعداد worker و concurrency باید با workload واقعی benchmark شود؛ عدد ثابت عمومی معتبر نیست.

## Environment Promotion

Dev → automated checks → Staging → integration/load/security → approval → Production → smoke test → observe → close release.

Credentialها همراه Git منتقل نمی‌شوند؛ فقط stub/reference و متغیرها طبق قابلیت محیط مدیریت می‌شوند. repository باید private باشد. Production ترجیحاً protected و بدون ویرایش دستی است.

## SLO پیشنهادی

- Availability برای trigger ingestion؛
- Successful completion rate؛
- end-to-end latency p50/p95/p99؛
- queue wait time؛
- duplicate side-effect rate؛
- recovery time؛
- data loss rate = 0 برای جریان‌های حیاتی.

Target باید برای هر Workflow تعیین شود؛ مثال عمومی جای قرارداد کسب‌وکار را نمی‌گیرد.

## Metrics

Throughput، success/failure، latency، retries، rate limits، queue depth، worker saturation، memory/CPU، DB connections، binary storage، AI tokens/cost و DLQ age.

## Alert Design

Alert باید symptom-based، دارای severity، owner، deduplication و runbook باشد. هشدار روی هر failure منفرد برای workload پرحجم مناسب نیست؛ از burn-rate و window استفاده شود.

## Backup و Disaster Recovery

Backup باید DB، encryption key، binary data، config، workflow source و credential recovery procedure را پوشش دهد. نگهداری backup بدون restore drill کافی نیست.

RPO و RTO باید صریح باشند. حداقل فصلی restore rehearsal و پس از تغییر عمده زیرساخت تکرار شود.

## Incident Flow

Detect → Triage → Contain → Recover → Validate → Communicate → RCA → Corrective actions.

RCA بدون سرزنش و شامل timeline، impact، trigger، contributing factors، detection gap، corrective owner و due date است.

## Capacity

قبل از Production با payload واقعی و latency سرویس‌های مقصد benchmark شود. concurrency بالا ممکن است API مقصد، DB یا memory را اشباع کند. کنترل backpressure و rate limit باید end-to-end باشد.

