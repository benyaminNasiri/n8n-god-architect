# امنیت و Governance

## Threat Model

دارایی‌ها: Credential، PII، داده درمانی/مالی، Workflow source، execution data و کانال‌های خروجی.

تهدیدها: credential leakage، prompt injection، SSRF، malicious node، webhook spoofing، excessive privilege، data exfiltration، replay، supply-chain و insider misuse.

## کنترل‌های پایه

- HTTPS و reverse proxy صحیح؛
- encryption key ثابت، امن و backup‌شده؛
- secrets در vault/external secret store؛
- جداسازی Dev/Staging/Prod؛
- least privilege برای user، project و service account؛
- MFA/SSO در صورت دسترسی؛
- allowlist nodeها و منع nodeهای پرخطر مگر با استثنا؛
- webhook authentication، signature، timestamp و replay protection؛
- محدودسازی outbound network و SSRF؛
- patch cadence و بررسی changelog؛
- اجرای دوره‌ای `n8n audit` یا API audit؛
- redaction و retention حداقلی execution data؛
- backup رمزنگاری‌شده و restore drill.

## AI Security

- محتوای ورودی به‌عنوان داده غیرقابل اعتماد تلقی شود؛
- system policy از retrieved content جدا بماند؛
- ابزارها schema محدود و allowlist داشته باشند؛
- destructive یا external side-effect tools نیازمند approval باشند؛
- secrets وارد prompt، memory و vector store نشوند؛
- خروجی مدل قبل از SQL/API/HTML validate و encode شود؛
- RAG اسناد را با tenant، ACL و provenance فیلتر کند؛
- مدل اجازه تغییر policy خود را نداشته باشد.

## Approval Matrix

| عملیات | Dev | Staging | Production |
|---|---|---|---|
| Read metadata | خودکار | خودکار | خودکار با audit |
| Draft workflow | خودکار | خودکار | ممنوع روی instance |
| Execute fixture | خودکار | خودکار | ممنوع |
| Publish workflow | مجاز | Approval تیم | مالک سرویس + reviewer |
| Delete data/workflow | Approval | Approval | دو تأیید + backup |
| Rotate credential | Approval | Approval | Security + owner |
| Bulk message/payment | sandbox | محدود | human-in-the-loop |

## Audit Record

هر تغییر باید actor، timestamp، environment، object ID، before/after hash، reason، approval، release ID و rollback reference داشته باشد.

## Data Classification

- Public
- Internal
- Confidential
- Restricted

برای Restricted: حداقل‌سازی، encryption، access logging، محدودیت retention، منع استفاده در مدل بدون قرارداد و بررسی محل پردازش الزامی است.

