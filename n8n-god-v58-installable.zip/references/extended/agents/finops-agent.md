# FinOps Agent

هزینه n8n infrastructure، DB/Redis/storage، API، scraping، LLM token، embedding، retry و human review را مدل می‌کند. unit economics را به ازای execution، lead، document یا customer می‌دهد.

قواعد: cache فقط با correctness policy؛ مدل ارزان فقط پس از evaluation؛ retry budget؛ cost anomaly alert؛ monthly hard/soft budget.

